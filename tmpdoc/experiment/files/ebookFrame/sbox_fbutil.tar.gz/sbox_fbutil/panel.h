/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Declaration of common panel API.

==============================================================================*/

#ifndef _PANEL_H
#define _PANEL_H

#include "fbcommon.h"

// This definitions are reinterpreted by specific panel device.
enum {
    PANEL_TYPE_NORMAL        =0,
    PANEL_TYPE_CLEAN,
    PANEL_TYPE_MAX
};

enum {
    PANEL_MODE_NORMAL       =0,
    PANEL_MODE_TEXT,
    PANEL_MODE_HIGHLIGHT,
    PANEL_MODE_HANDWRITING,
    PANEL_MODE_OTHER,
    PANEL_MODE_MAX
};

typedef struct
{
    int (*busy)(int fd);
    int (*update)(fb_data_t const *fbdata, int type, int mode, int x, int y, int w, int h);
}
panel_api_t;

typedef void (*pfn_panel_init_t)(panel_api_t * panel);

int panel_init(const char* name, panel_api_t * panel);

#endif //_PANEL_H

