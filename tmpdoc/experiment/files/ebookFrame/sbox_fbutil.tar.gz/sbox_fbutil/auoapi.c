/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    AUO k1900 panel API implementation.

==============================================================================*/
    
// config.h defines the panel interface:
// _PANEL_PVI_API_, _PANEL_PVI_API_
#include "config.h"

#ifdef _PANEL_AUO_API_

#include "panel.h"
#include "fbcommon.h"
#include "s3cfb_epd_g1.h"
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>

extern int g_b_silent;

static int auo_is_busy(int fd)
{
    int busy = 0;
    if (ioctl(fd, FBIO_AUO_TCON_BUSY, &busy) != 0) {
        perror("Error: ioctl FBIO_AUO_TCON_BUSY ");
        return (uint)-1;
    }
    return busy;
}

/*

type : update type, set 1 to use clean type, otherwise, dirty type. [0,1]
mode : update wavemode, indicating how many bits per pixel. [0,4]

AUO panel does not support standalone `type`, there is a mode_0 used to 
clear screen, which will cause obvious flashing.

PANEL_TYPE_NORMAL           //
PANEL_TYPE_CLEAN            //mode=EPD_DISPLAY_REFRESH_MODE_FLASH

PANEL_MODE_NORMAL           //mode=EPD_DISPLAY_REFRESH_MODE_NO_FLASH
PANEL_MODE_TEXT             //mode=EPD_DISPLAY_TEXT_MODE
PANEL_MODE_HIGHLIGHT        //mode=EPD_HIGH_SPEED_MODE
PANEL_MODE_HANDWRITING      //mode=EPD_HANDWRITING_MODE
PANEL_MODE_OTHER            //mode=EPD_DISPLAY_REFRESH_MODE_NO_FLASH

*/
static int auo_update(fb_data_t const *fbdata, int type, int mode, int x, int y, int w, int h)
{
    // interpret mode first. because upd_type could change mode too.
    if (PANEL_MODE_NORMAL == mode) { mode = EPD_DISPLAY_REFRESH_MODE_NO_FLASH; }
    else if (PANEL_MODE_TEXT == mode) { mode = EPD_DISPLAY_TEXT_MODE; }
    else if (PANEL_MODE_HIGHLIGHT == mode) { mode = EPD_HIGH_SPEED_MODE; }
    else if (PANEL_MODE_HANDWRITING == mode) { mode = EPD_HANDWRITING_MODE; }
    else if (PANEL_MODE_OTHER == mode) { mode = EPD_AUTO_SELECTION_MODE; }
    else { mode = EPD_DISPLAY_REFRESH_MODE_NO_FLASH; }

    // interpret type
    if (PANEL_TYPE_NORMAL == type) { ; }
    else if (PANEL_TYPE_CLEAN == type) { mode = EPD_DISPLAY_REFRESH_MODE_FLASH; }
    else { ; }

    // init params for ioctl.
    update_area_t info;
    memset(&info, 0, sizeof(update_area_t));
    
    info.mode = mode;
    info.x = x;
    info.y = y;
    info.w = w;
    info.l = h;
    
    // mode 4 needs more flags.
    if(EPD_HANDWRITING_MODE == info.mode)
    {
        info.flashbit = 1;
        info.set_handwriting_area = 1;
    }
    
    //=============================================== alignment begins

    // x and y should be aligned as 2n+1.
    int tx = (info.x | 1);
    int ty = (info.y | 1);

    // w and h should be aligned by 4.
    // if original x y are odd, then the width and height must be added 1.
    int tw = (info.w + (info.x & 1) + 0x3) & (~0x3);
    int th = (info.l + (info.y & 1) + 0x3) & (~0x3);

    // tw and th are already 4 aligned, if out of size, just reduce 4 recursively.
    for(; info.x+tw > fbdata->w; tw-=4){};
    for(; info.y+th > fbdata->h; th-=4){};

    // copy the values back.
    info.x = tx;
    info.y = ty;
    info.w = tw;
    info.l = th;

    //=============================================== alignment ends

	if(!g_b_silent)printf("AUO_UPDATE : [mode=%d] [rect=(%u,%u,%ux%u)]\n", mode, x, y, w, h);
    if (ioctl(fbdata->fd, (FBIO_AUO_UPDATE_DISPLAY_PARTIAL), &info))
    {
        perror("Error: ioctl FBIO_AUO_UPDATE_DISPLAY_PARTIAL ");
        return (uint)-1;
    }
    return 0;
}

// init panel_api_t.
void auo_panel_init(panel_api_t* panel)
{
    panel->busy     = auo_is_busy;
    panel->update   = auo_update;
}

pfn_panel_init_t pfn_auo_panel_init = auo_panel_init;

#endif //_PANEL_AUO_API_

