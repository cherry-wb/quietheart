/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Declarations of picture loader.

==============================================================================*/

#ifndef _PICREADER_H
#define _PICREADER_H

//return value need to be freed.
char* pic_load_from_file(const char* file_name, int *w, int *h);

//destroy the png buffer.
void pic_drop_buf(char* buf);

#endif //_PICREADER_H

