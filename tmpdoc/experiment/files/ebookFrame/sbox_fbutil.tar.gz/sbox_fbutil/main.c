/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    This is a simple framebuffer testing tool for e-paper panel. PVI s1d13522 
and AUO k1900 panels are supported at present.

==============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>

#include "fbcommon.h"
#include "panel.h"
#include "picloader.h"

#define PVI     "pvi"
#define AUO     "auo"

//==============================================================================
// type definition

typedef struct
{
    int x, y, w, h;
}
rect_t;

typedef struct
{
    int r, g, b;
}
color_t;

// use one int as 32 bools.
typedef union
{
    int value;
    struct
    {
        int b_file      : 1;
        int b_dir       : 1;
        int b_grad      : 1;
        int b_color     : 1;
        int b_switch    : 1;
        int b_paint     : 1;
    }f;
}
record_t;

typedef struct
{
    record_t    record;         //= {0}
    char *      s_file;         //= NULL;
    char *      s_dir;          //= NULL;
    int         i_intv;         //= 0; //time interval
    rect_t      r_view;         //= {0,0,600,800};
    int         b_gradient;     //= 0; //1 means use gradient color.
    color_t     a_colors[2];    //= {{0}};
    int         i_orie;         //= 0;
    int         b_switch;       //= 0;

    char *      s_name;         //= NULL;
    int         i_mode;         //= 0; //update mode.
    int         i_type;         //= 0; //only used in pvi screen.
}
args_t;


//==============================================================================
// static variable

int                 g_b_fake   = 0; // no real update, just write buffer.
int                 g_b_sync   = 0; // wait until device is idle again.
int                 g_b_silent = 0; // extern to other module.
int                 g_b_alpha  = 0; // enable alpha blending.
int                 g_b_centre = 0; // move image to center.
int                 g_b_fbinfo = 0; // extern to fbcommon module.
static args_t       g_args;
static panel_api_t  panel;
static fb_data_t    fb_data;


//==============================================================================
// option parser and usage message.

static void show_usage()
{
    printf( "Usage: fbtest [options]\n"
"    options = a.cd.fghi...mnopqrst..w..z\n"
"    -h  Show this help.\n"
"    -n <name> Name of the screen panel. (\"pvi\" or \"auo\")\n"
"    -q  Be silent on tty.\n"
"    -i  Show framebuffer info. If -q is set, this option is ignored.\n"
"        If no option is set, this one will be the default.\n"
"    -s  Update is synchronized. This is often used to test performance.\n"
"        Panels which do not support synchronization just ignore this.\n"
"    -a  Enable alpha blending if necessary.\n"
"    -o  Only write buffer but no real update.\n"
"    -z  Show image in the centre of the screen, only has effect on -f, -d.\n"
"    -r <x,y,w,h> Rect of virtual screen.\n"
"    -f <string> Png filename, print png to the screen.\n"
"        Note that this program does not support Alpha Transparency.\n"
"        Option -f will override -d[-t] -c and -g.\n"
"        Priority : -f > -d[-t] > -c > -g > -w\n"
"    -c <R,G,B> Paint pure color. RGB is translated to grayscale anyway.\n"
"    -g <R1,G1,B1:R2,G2,B2:orie> Show linear gradient from RGB1 to RGB2,\n"
"        Orientation is set by orie[0,1]. 0:top-bottom, 1:left-right.\n"
"    -m <mode:type> Update screen with mode and type.\n"
"        Mode [0,3] indicates update bits depth.\n"
"        0 = Normal flash mode.\n"
"        1 = Text flash mode.\n"
"        2 = Highlight flash mode.\n"
"        3 = Handwriting flash mode.\n"
"        Type [0,1] determines to flash clearly or not to.\n"
"        0 = Non-clear update type.\n"
"        1 = Clear update type.\n"
"    -w  Switch between black and white, often with -r and -t.\n"
"    NOTE : All definitions above are reinterpreted by specific panel.\n"
"    \n"
"    The following options are not supported now.\n"
"    -d <string> Png dirpath, print pngs in the dirpath.\n"
"        Png filename must be of format \"XXXX.png\", XXXX is [0000-9999].\n"
"    -t <int>, slideshow time interval, 0 means no slideshow. see -d option.\n"
"    -p  Painting (only touch penel supported).\n"
"    \n"
    );
}

void parse_opt( int argc, char *argv[], args_t * args )
{
    assert(NULL!=args);
    
    memset(args, 0, sizeof(args_t));
    
    int i;
    for ( i=1; i<argc; i++ ) {
        if (!strcmp("-h", argv[i])){ show_usage(); exit(0); }
        else
        if (!strcmp("-q", argv[i])){ g_b_silent = 1; }
        else
        if (!strcmp("-i", argv[i])){ g_b_fbinfo = 1; }
        else
        if (!strcmp("-s", argv[i])){ g_b_sync = 1; }
        else
        if (!strcmp("-a", argv[i])){ g_b_alpha = 1; }
        else
        if (!strcmp("-z", argv[i])){ g_b_centre = 1; }
        else
        if (!strcmp("-o", argv[i])){ g_b_fake = 1; }
        else
        if (!strcmp("-w", argv[i])){ args->record.f.b_switch = 1; }
        else
        if (!strcmp("-p", argv[i])){ args->record.f.b_paint = 1; }
        else
        if (!strcmp("-n", argv[i]) && (i+1<argc)){ args->s_name = argv[++i]; }
        else
        if (!strcmp("-f", argv[i]) && (i+1<argc))
        {
            args->s_file = argv[++i];
            args->record.f.b_file = 1;
        }
        else
        if (!strcmp("-d", argv[i]) && (i+1<argc))
        {
            args->s_dir = argv[++i];
            args->record.f.b_dir = 1;
        }
        else
        if (!strcmp("-t", argv[i]) && (i+1<argc))
        {
            char * str = argv[++i];
            int ret = sscanf(str, "%d", &args->i_intv);
            if (1 != ret)
            {
                printf("Option Error : -t option is invalid!\n");
                show_usage(); exit(-1);
            }
        }
        else
        if (!strcmp("-c", argv[i]) && (i+1<argc))
        {
            char * str = argv[++i];
            int ret = sscanf(str, "%d,%d,%d", &args->a_colors[0].r,
                        &args->a_colors[0].g, &args->a_colors[0].b);
            if (3 != ret)
            {
                printf("Option Error : -c option is invalid!\n");
                show_usage(); exit(-1);
            }
            args->record.f.b_color = 1;
        }
        else
        if (!strcmp("-g", argv[i]) && (i+1<argc))
        {
            args->b_gradient = 1;
            char * str = argv[++i];
            int ret = sscanf(str, "%d,%d,%d:%d,%d,%d:%d", &args->a_colors[0].r,
                                &args->a_colors[0].g, &args->a_colors[0].b,
                                &args->a_colors[1].r, &args->a_colors[1].g,
                                &args->a_colors[1].b, &args->i_orie);
            if (7 != ret)
            {
                printf("Option Error : -g option is invalid!\n");
                show_usage(); exit(-1);
            }
            args->record.f.b_grad = 1;
        }
        else
        if (!strcmp("-r", argv[i]) && (i+1<argc))
        {
            char * str = argv[++i];
            int ret = sscanf(str, "%d,%d,%d,%d", &args->r_view.x,
                        &args->r_view.y, &args->r_view.w, &args->r_view.h);
            if (4 != ret)
            {
                printf("Option Error : -r option is invalid!\n");
                show_usage(); exit(-1);
            }
        }
        else
        if (!strcmp("-m", argv[i]) && (i+1<argc))
        {
            char * str = argv[++i];
            int ret = sscanf(str, "%d:%d", &args->i_mode, &args->i_type);
            if (2 != ret) { show_usage(); exit(0); }
            if (args->i_mode >= PANEL_MODE_MAX
                || args->i_mode < 0
                || args->i_type >= PANEL_TYPE_MAX
                || args->i_type < 0)
            {
                printf("Option Error : -m option out of range!\n");
                show_usage(); exit(-1);
            }
        }
        else
        {
            show_usage(); exit(-1);
        }
    }
    
    // log something out.
    if (args->record.value)
    {
        if (NULL == args->s_name)
        {
            printf("Option Error : -n option must be set, if any of -f -d -c -g is set!\n");
            show_usage(); exit(-1);
        }
        
        if(!g_b_silent) printf(
            "%s : %s=%s, interval=%d\n"
            "      rect=(%d,%d,%dx%d), mode=%d, type=%d, grad=%d, orie=%d\n"
            "      color[0](%d,%d,%d), color[1](%d,%d,%d)\n", 
            args->s_name ? args->s_name : "N/A",
            (args->s_file ? "file" : "dir"),
            (args->s_file ? args->s_file : (args->s_dir ? args->s_dir : "NULL")),
            args->i_intv,
            args->r_view.x, args->r_view.y, args->r_view.w, args->r_view.h,
            args->i_mode, args->i_type, args->b_gradient, args->i_orie,
            args->a_colors[0].r, args->a_colors[0].g, args->a_colors[0].b,
            args->a_colors[1].r, args->a_colors[1].g, args->a_colors[1].b
            );
    }
}


//==============================================================================
// common fb process flow.

// draw a png image to screen panel.
void draw_image(const char * path, rect_t * r)
{
    if(!g_b_silent)printf("drawing png image ...\n");
    assert(NULL!=path && NULL!=r);
    
    int pic_w=0;
    int pic_h=0;
    char* picbuf = pic_load_from_file(path, &pic_w, &pic_h);
    // move image to the centre of the screen, if g_b_centre is 1.
    if (g_b_centre)
    {
        int w = pic_w < r->w ? pic_w : r->w;
        int h = pic_h < r->h ? pic_h : r->h;
        int x = (fb_data.w - w) / 2;
        int y = (fb_data.h - h) / 2;
        r->x = x; r->y = y; r->w = w; r->h = h;
    }
    if (picbuf != NULL)
    {
        fb_write_buf(&fb_data, r->x, r->y, r->w, r->h, fb_data.w, 
                                        picbuf, 0, 0, pic_w, pic_h, pic_w);

        if (!g_b_fake)
        {
            (*panel.update)(&fb_data, g_args.i_type, g_args.i_mode,
                                                    r->x, r->y, r->w, r->h);
        }
    
        pic_drop_buf(picbuf);
    }
    else
    {
        printf("[error] Cannot open file %s.\n", path);
    }
}

// draw pure color to panel.
void draw_pure_color(const color_t * c, const rect_t * r)
{
    if(!g_b_silent)printf("drawing pure color ...\n");
    assert(NULL!=c && NULL!=r);

    //fb_paint_gray
    uchar gray = (4==fb_data.bpp) ? GRAY4(c->r, c->g, c->b) : GRAY8(c->r, c->g, c->b);
    fb_paint_gray(fb_data.bpp, fb_data.base, r->x,r->y,r->w,r->h, fb_data.w, gray);
    
    if (!g_b_fake)
    {
        (*panel.update)(&fb_data, g_args.i_type, g_args.i_mode,
                                                    r->x, r->y, r->w, r->h);
    }
}

// draw linear-gradient color
void draw_gradient(const color_t *c_1, const color_t *c_2, int orie, const rect_t *r)
{
    //XXX to be done. test rect
    if(!g_b_silent)printf("drawing gradient color ...\n");
    assert(NULL!=c_1 && NULL!=c_2 && NULL!=r);
    
    int gray0 = (4==fb_data.bpp) ? GRAY4(c_1->r, c_1->g, c_1->b)
                                 : GRAY8(c_1->r, c_1->g, c_1->b);
    int gray1 = (4==fb_data.bpp) ? GRAY4(c_2->r, c_2->g, c_2->b)
                                 : GRAY8(c_2->r, c_2->g, c_2->b);
    int diff = gray1-gray0;
    //
    if (0==orie) // top-bottom
    {
        int y;
        for(y=r->y; y<r->y+r->h && y<fb_data.h; y++)
        {
            int gray = gray0 + 1.0 * (y-r->y) / r->h * diff;
            fb_paint_gray(fb_data.bpp, fb_data.base,
                                        r->x, y, r->w, 1, fb_data.w, gray);
        }
    }
    else
    if (1==orie) // left-right
    {
        pfn_write_pixel_t write_pixel = (4==fb_data.bpp)
                                      ? fb_write_pixel_gray4
                                      : fb_write_pixel_gray8;
        // fill the first line.
        char * first_line = fb_data.base + (r->y*fb_data.w*fb_data.bpp/8);
        int x;
        for(x=r->x; x<(r->x+r->w); x++)
        {
            write_pixel(first_line, x, gray0+(1.0*(x-r->x)/r->w*diff), 255);
        }
        // copy the first line to others from 2rd line.
        int y;
        for(y=r->y+1; y<(r->y+r->h) && y<fb_data.h; y++)
        {
            char* line_base = fb_data.base + y*fb_data.w*fb_data.bpp/8 ;
            memcpy(line_base+r->x*fb_data.bpp/8, first_line+r->x*fb_data.bpp/8,
                        ((r->x+r->w)*fb_data.bpp+7)/8-r->x*fb_data.bpp/8);
        }
    }
    if (!g_b_fake)
    {
        (*panel.update)(&fb_data, g_args.i_type, g_args.i_mode,
                                                    r->x, r->y, r->w, r->h);
    }
}

// switch between black and white, 10 times.
void draw_black_white_switch(const rect_t *r)
{
    if(!g_b_silent)printf("switch between black and white ...\n");
    assert(NULL!=r);

    color_t black = {0,0,0};
    color_t white = {255,255,255};
    int i;
    for(i=0; i<20; i++)
    {
        if (i&1)
        {
            draw_pure_color(&black, r);
        }
        else
        {
            draw_pure_color(&white, r);
        }
        if (g_args.i_intv)
        {
            usleep(g_args.i_intv * 1000);
        }
    }
}

// draw slide show
void draw_serial_images()
{
    //XXX to be done.
    if(!g_b_silent)printf("drawing png images ...\n");
}

int panel_process_main(args_t const * args)
{
    // init panel api.
    if (-1 == panel_init(args->s_name, &panel))
    {
        return -1;
    }
    
    // connect fb and init fb_data_t.
    fb_connect("/dev/fb0", &fb_data);

    // handle -r option.
    rect_t rect = args->r_view;
    if (0==rect.w || 0==rect.h)
    {
        // -r is not set or invalid, use full screen.
        rect.x = 0; rect.y = 0; rect.w = fb_data.w; rect.h = fb_data.h;
    }
    else
    {
        rect.x = (uint)args->r_view.x % (fb_data.w);
        rect.y = (uint)args->r_view.y % (fb_data.h);
        // choose the smaller w and h to ensure safe.
        rect.w = args->r_view.w < (fb_data.w - rect.x) ? args->r_view.w
                                                       : (fb_data.w - rect.x);
        rect.h = args->r_view.h < (fb_data.h - rect.y) ? args->r_view.h
                                                       : (fb_data.h - rect.y);
    }
    // from now on , rect is valid.

    // option priority : -f > -d > -c > -g

    // handle -f option
    if (args->s_file != NULL)
    {
        draw_image(args->s_file, &rect);
    }
    else
    // handle -d and -t option
    if (args->s_dir != NULL)
    {
        draw_serial_images();
    }
    else
    // handle -c
    if (args->record.f.b_color)
    {
        draw_pure_color(&(args->a_colors[0]), &rect);
    }
    else
    // handle -g
    if (args->record.f.b_grad)
    {
        draw_gradient(&(args->a_colors[0]), &(args->a_colors[1]), args->i_orie, &rect);
    }
    else
    // handle -w
    if (args->record.f.b_switch)
    {
        draw_black_white_switch(&rect);
    }
#if 0 // this is only for test.
    else
    // handle -p
    if (args->record.f.b_paint)
    {
#include "tslib.h"
        struct tsdev *ts;
        char *tsdevice=NULL;

        if( (tsdevice = getenv("TSLIB_TSDEVICE")) != NULL ) {
            ts = ts_open(tsdevice,0);
        }
        else
        {
            printf("env TSLIB_TSDEVICE is not set, quit now !!\n");
            return -1;
        }
        
        if (!ts) {
            perror("ts_open");
            exit(1);
        }
        
        if (ts_config(ts)) {
            perror("ts_config");
            exit(1);
        }
        
        while (1) {
            struct ts_sample samp;
            int ret;
        
            ret = ts_read_raw(ts, &samp, 1);
        
            if (ret < 0) {
                perror("ts_read");
                exit(1);
            }
        
            if (ret != 1)
                continue;

            // now we have got a valid sample.
            //printf("%ld.%06ld: %6d %6d %6d\n", samp.tv.tv_sec, samp.tv.tv_usec, samp.x, samp.y, samp.pressure);
            if (samp.pressure)
            {
                // paint (x,y) black.
                fb_paint_gray(fb_data.bpp, fb_data.base, 
                                        samp.x, samp.y, 1, 1, fb_data.w, 0);
                if (!panel.busy(fb_data.fd))
                {
                    if (!g_b_fake)
                    {
                        (*panel.update)(&fb_data, g_args.i_type, g_args.i_mode, 0,0,600,800);
                    }
                }
            }
        }
    }
#endif // handle -p
    
    fb_disconnect(&fb_data);
    return 0;
}


//==============================================================================
// main

int main( int argc, char *argv[] )
{
    parse_opt(argc, argv, &g_args);

    if (0 == g_args.record.value)
    {
        g_b_fbinfo = 1;
        // None of -f, -d, -c, -g is set, just show fb info and exit.
        fb_data_t       fb_data;
        fb_connect("/dev/fb0", &fb_data);
        fb_disconnect(&fb_data);
    }
    else
    if (!strcmp(g_args.s_name,PVI) || !strcmp(g_args.s_name,AUO))
    {
        panel_process_main(&g_args);
    }
    else
    {
        printf("Do not support Screen Device %s !\n", g_args.s_name);
    }
    
    return 0;
}

