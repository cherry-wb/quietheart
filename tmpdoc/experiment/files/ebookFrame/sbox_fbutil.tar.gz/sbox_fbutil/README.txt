         _   _  _____  _   _   _____  ___   _____  _____ 
        | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
        |  \| || |__  | | | || (___ | / \ || |___   | |  
        | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
        | |\  || |___ | |_| | ___) || \_/ || |      | |  
        |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                   Copyright (C) 2010 Neusoft.

Description :
This is a simple framebuffer test tool for auo and pvi panels.
At present, AUO k1900 and PVI s1d13521/s1d13522 are supported.

Usage :
	Just type "./fbutil -h" to see the usage.

Examples :

1, to see framebuffer info.
	./fbutil
	./fbutil [other options] -i

2, to print a png image to the centre of the screen panel.
	./fbutil -n pvi -f /path/of/png/file -z

3, to print a series of png images. (not support now)
	./fbutil -n pvi -d /dirpath/of/png/files -t interval

4, to paint a pure color.
	./fbutil -n auo -c 255,128,64

5, to paint gradient of 2 colors.
	./fbutil -n auo -g 255,255,255:0,0,0:1

6, to set virtual screen rectangle.
	./fbutil -n pvi [other options] -r 100,100,400,200
	If -r is not set, use default rect (0,0,600,800).

7, to set update mode and type.
	./fbutil -n auo [other options] -m 0:1

Note :
	If any drawing option (such as -f -d -c -g) is set, then
	-n <panel name> must be set to indicate which panel API
	will be invoked.

	Drawing options priority : -f > -d[-t] > -c > -g
