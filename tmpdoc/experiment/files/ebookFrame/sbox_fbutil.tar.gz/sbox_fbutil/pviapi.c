/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    PVI s1d13522 panel API implementation.

==============================================================================*/
    
// config.h defines the panel interface:
// _PANEL_PVI_API_, _PANEL_PVI_API_
#include "config.h"

#ifdef _PANEL_PVI_API_

#include "panel.h"
#include "fbcommon.h"
#include "s1d13522.h"
#include "s1d13522ioctl.h"
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>

#include <time.h>
#include <sys/time.h>
#include <unistd.h>

extern int g_b_silent;
extern int g_b_sync;

typedef struct s1d13522_ioctl_hwc   s1d13522_ioctl_hwc;

static uint pvi_read_reg(int fd, uint addr)
{
    s1d13522_ioctl_hwc ioctl_hwc;
    ioctl_hwc.addr = addr;
    if (ioctl(fd, S1D13522_REGREAD, &ioctl_hwc)) {
        perror("Error: ioctl S1D13522_REGREAD ");
        return (uint)-1;
    }
    return ioctl_hwc.value;
}

static uint pvi_write_reg(int fd, uint addr, uint value)
{
    s1d13522_ioctl_hwc ioctl_hwc;
    ioctl_hwc.addr = addr;
    ioctl_hwc.value = value;
    if (ioctl(fd, S1D13522_REGWRITE, &ioctl_hwc)) {
        perror("Error: ioctl S1D13522_REGWRITE ");
        return (uint)-1;
    }
    return 0;
}

// return 0 if screen is not busy.
static int pvi_is_busy(int fd)
{
    return ((pvi_read_reg(fd, 0x000A) & 0xC0FC) != 0);
}

/*

type : update type, set 1 to use clean type, otherwise, dirty type. [0,1]
mode : update wavemode, indicating how many bits per pixel. [1,3]

PANEL_TYPE_NORMAL           //type=S1D13522_UPD_PART_AREA;
PANEL_TYPE_CLEAN            //type=S1D13522_UPD_FULL_AREA;

PANEL_MODE_NORMAL           //mode=WF_MODE_GC16;
PANEL_MODE_TEXT             //mode=WF_MODE_GC16;
PANEL_MODE_HIGHLIGHT        //mode=WF_MODE_GC4;
PANEL_MODE_HANDWRITING      //mode=WF_MODE_MU;
PANEL_MODE_OTHER            //mode=WF_MODE_GC16;

*/
static int pvi_update(fb_data_t const *fbdata, int type, int mode, int x, int y, int w, int h)
{
    // interpret type
    if (PANEL_TYPE_NORMAL == type) { type = S1D13522_UPD_PART_AREA; }
    else if (PANEL_TYPE_CLEAN == type) { type = S1D13522_UPD_FULL_AREA; }
    else { type = 0; }

    // interpret mode
    if (PANEL_MODE_NORMAL == mode) { mode = WF_MODE_GC16; }
    else if (PANEL_MODE_TEXT == mode) { mode = WF_MODE_GC16; }
    else if (PANEL_MODE_HIGHLIGHT == mode) { mode = WF_MODE_GC4; }
    else if (PANEL_MODE_HANDWRITING == mode) { mode = WF_MODE_MU; }
    else if (PANEL_MODE_OTHER == mode) { mode = WF_MODE_GC16; }
    else { mode = WF_MODE_GC16; }

    #if 0
    if (g_b_sync)
    {
        s1d13522_ioctl_cmd_params cmd_params;
        cmd_params.param[0] = UPD_FULL;
        cmd_params.param[1] = WF_MODE_GC16;
        if (ioctl(fbdata->fd, S1D13522_VBUF_REFRESH, &cmd_params)) {
            printf("Error: ioctl S1D13522_VBUF_REFRESH.\n");
            return -1;
        }
        return 0;
    }
    #endif

    int rate = 6;
    FILE * fp = fopen("/tmp/pvirate", "rb");
    if (fp)
    {
        fscanf(fp, "%d", &rate);
    }
    uint r_0018 = pvi_read_reg(fbdata->fd, 0x0018);
    printf("REG[0018] = %x, SET RET[0018] %d\n", r_0018, rate);
    pvi_write_reg(fbdata->fd, 0x0018, rate);

    struct timeval time_s={0}, time_e={0}, time_inc={0};
    gettimeofday(&time_s, NULL);

    // this param is reused by all ioctl()s below,
    // so make sure it is clean before using it.
	s1d13522_ioctl_cmd_params cmd_params;
	
	// write reg 330h <- 0x84
	pvi_write_reg(fbdata->fd, 0x330, 0x84);
	
	// notify transit
    cmd_params.param[0] = (0x3<<4);
	if (ioctl(fbdata->fd, S1D13522_LD_IMG, &cmd_params)) {
	    perror("Error: ioctl S1D13522_LD_IMG ");
	    return -1;
	}
	
	// write reg 0x154h <- 0
    pvi_write_reg(fbdata->fd, 0x154, 0);
    
	// burst write memory
    s1d13522_ioctl_hwc ioctl_hwc;
    ioctl_hwc.buffer = fbdata->base;
    ioctl_hwc.value = fbdata->size;
	if (ioctl(fbdata->fd, S1D13522_MEMBURSTWRITE, &ioctl_hwc)) {
	    perror("Error: ioctl S1D13522_MEMBURSTWRITE ");
	    return -1;
	}
	
	// wait for transit done
	memset(&cmd_params, 0, sizeof(cmd_params));
	if (ioctl(fbdata->fd, S1D13522_LD_IMG_END, &cmd_params)) {
	    perror("Error: ioctl S1D13522_LD_IMG_END ");
	    return -1;
	}
	
	// notify update
	int n_lut = 0xF;
	int n_bdr = 0;
	cmd_params.param[0] = ((mode&0xF)<<8)|((n_lut&0xF)<<4)|((n_bdr&0x1)<<14);
	cmd_params.param[1] = (ushort)x;
	cmd_params.param[2] = (ushort)y;
	cmd_params.param[3] = (ushort)w;
	cmd_params.param[4] = (ushort)h;

	// invoke ioctl()
	if(!g_b_silent)printf("PVI_UPDATE : [type=0x%x] [mode=%d] [rect=(%u,%u,%ux%u)]\n", type, mode, x, y, w, h);

	// send the real update command
	if (ioctl(fbdata->fd, type, &cmd_params)) {
	    perror("Error: ioctl S1D13522_UPD_* ");
	    return -1;
	}

    #if 1
    // wait for update done, if necessary.
	if (0!=g_b_sync)
	{
	    if(!g_b_silent)
	    {
	        printf("PVI_UPDATE : synchronizing ... ");
	        fflush(stdout);
	    }
	    memset(&cmd_params, 0, sizeof(cmd_params));
        if (ioctl(fbdata->fd, S1D13522_WAIT_DSPE_TRG, &cmd_params)) {
            perror("Error: ioctl WAIT_DSPE_TRG ");
            return -1;
        }
        if (ioctl(fbdata->fd, S1D13522_WAIT_DSPE_FREND, &cmd_params)) {
            perror("Error: ioctl WAIT_DSPE_FREND ");
            return -1;
        }
        while(0!=pvi_is_busy(fbdata->fd))
        {
            usleep(5000);
        }
	    if(!g_b_silent)printf("done!\n");
	}
	#endif

    gettimeofday(&time_e, NULL);
    
    int borrow = (int)(time_e.tv_usec < time_s.tv_usec); // 0 or 1
    time_inc.tv_usec = time_e.tv_usec - time_s.tv_usec + borrow * 1000000;
    time_inc.tv_sec = time_e.tv_sec - time_s.tv_sec - borrow;
    printf("PVI_UPDATE : screen update takes time [%5ld.%06ld] sec\n", 
                                        time_inc.tv_sec, time_inc.tv_usec);

	#if 0 // easy way to invoke synchronized, full screen update.
	s1d13522_ioctl_cmd_params cmd_params;
	cmd_params.param[0] = UPD_FULL;
	cmd_params.param[1] = WF_MODE_GC16;
	TimeLog::start(NULL);
	if (ioctl(fbfd, S1D13522_VBUF_REFRESH, &cmd_params)) {
	    printf("Error: ioctl S1D13522_VBUF_REFRESH.\n");
	}
	#elif 0 // rotate the screen by hardware.
	int rotation = 1; // rotation is [1,4]
	s1d13522_ioctl_cmd_params cmd_params;
    cmd_params.param[0] = (rotation << 8);
    if (ioctl(fbfd, S1D13522_INIT_ROTMODE, &cmd_params)) {
        printf("Error: ioctl S1D13522_INIT_ROTMODE.\n");
    }
	#endif

	return 0;
}

// init panel_api_t.
void pvi_panel_init(panel_api_t* panel)
{
    panel->busy     = pvi_is_busy;
    panel->update   = pvi_update;
}

pfn_panel_init_t pfn_pvi_panel_init = pvi_panel_init;

#endif //_PANEL_PVI_API_

