/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Declaration of common functions of framebuffer.

==============================================================================*/

#ifndef _FBCOMMON_H
#define _FBCOMMON_H

typedef unsigned char   uchar;
typedef unsigned short  ushort;
typedef unsigned int    uint;

typedef struct
{
    int             fd;
    char *          base;
    int             w;
    int             h;
    int             size;
    int             bpp; //bits per line.
}
fb_data_t;

typedef void (*pfn_write_pixel_t)(char *line_base, int offset, uchar gray, uchar alpha);
typedef uchar (*pfn_gray_from_rgb32_t)(int rgb32);

// init fb_data_t
void fb_connect(const char* devpath, fb_data_t* fbdata);

// unmap the buffer and close fd.
void fb_disconnect(fb_data_t* fbdata);

#define GRAY8(r, g, b)   ((r*11+g*16+b*5)/32)
#define GRAY4(r, g, b)   (((r*11+g*16+b*5)/32)>>4)

inline uchar fb_argb32_to_gray4(int argb);
inline void fb_write_pixel_gray4(char * line_base,int offset,uchar gray, uchar alpha);
inline uchar fb_argb32_to_gray8(int argb);
inline void fb_write_pixel_gray8(char * line_base,int offset,uchar gray, uchar alpha);

// write image buffer to framebuffer.
inline void fb_write_buf(fb_data_t* fbdata, int dx, int dy, int dw, int dh, int dstride, 
                void * src32, int sx, int sy, int sw, int sh, int sstride);

// draw pure color rect to framebuffer.
inline void fb_paint_gray(int dstbpp, void * dstbuf, int dx, int dy, int dw, int dh,
                                                    int dstride, uchar gray);

#endif //_FBCOMMON_H

