/****************************************************************************
 * **
 * ** This file is part of screen driver
 * **
 * ** Copyright (C) 2010 Neusoft.
 * **
 * ** This module defines symbols which are used by Qt screen driver module.
 * **
 * ****************************************************************************/

#ifndef __S3CFB_EPD_G1_H
#define __S3CFB_EPD_G1_H

//// IOCTL COMMAND ////////////////////////////////////////////////////////////////////////////////
#define FBIO_AUO_UPDATE_DISPLAY_FULL				_IO('F', 100)
#define FBIO_AUO_UPDATE_DISPLAY_PARTIAL				_IOW('F', 101, update_area_t *)
#define FBIO_AUO_N_UPDATE_DISPLAY_PARTIAL			_IOW('F', 103, update_area_t *)
#define FBIO_AUO_RESTORE_DISPLAY				_IO('F', 102)
#define FBIO_AUO_COMMAND_TESTING				_IOW('F', 112, unsigned short)
#define FBIO_AUO_SET_POWER_NORMAL				_IO('F', 114)
#define FBIO_AUO_SET_POWER_SLEEP				_IO('F', 115)
#define FBIO_AUO_SET_POWER_STANDBY				_IO('F', 116)
#define FBIO_AUO_SET_ROTATE_0					_IO('F', 119)
#define FBIO_AUO_SET_ROTATE_90					_IO('F', 120)
#define FBIO_AUO_SET_ROTATE_180					_IO('F', 121)
#define FBIO_AUO_SET_ROTATE_270					_IO('F', 122)
#define FBIO_AUO_INFORMATION_READ				_IO('F', 123)
#define FBIO_AUO_SET_DISPLAY_REFRESH				_IO('F', 124)
#define FBIO_AUO_SET_DISPLAY_RESET				_IO('F', 125)
#define FBIO_AUO_STATUS_READ					_IO('F', 126)
//#define FBIO_AUO_TCON_FUNCTIONS_READ				_IO('F', 127)
#define FBIO_AUO_SET_DISPLAY_SLEEP				_IO('F', 128)
#define FBIO_AUO_SET_DISPLAY_NONE_SLEEP				_IO('F', 129)
#define FBIO_AUO_TCON_RESET_0					_IO('F', 132)
//#define FBIO_AUO_TCON_INFO_READ					_IO('F', 134)
#define FBIO_AUO_TCON_HW_RESET					_IO('F', 135)
#define FBIO_AUO_TCON_BUSY					_IO('F', 136)
//////////////////////////////////////////////////////////////////////////////////////////////////

#define EPD_DISPLAY_REFRESH_MODE_FLASH				0x0
#define EPD_DISPLAY_REFRESH_MODE_NO_FLASH			0x1
#define EPD_DISPLAY_TEXT_MODE					0x2
#define EPD_HIGH_SPEED_MODE					0x3
#define EPD_HANDWRITING_MODE					0x4
#define EPD_AUTO_SELECTION_MODE					0x5

/* For use with image update structure */
struct _update_area_t
{
	int flashbit;		// 1: draw black color; 0: draw white color
	int mode;
    #if 0 //zhaohp
	unsigned int x;
	unsigned int y;
	unsigned int w;
	unsigned int l;
    #else
	int x;
	int y;
	int w;
	int l;
    #endif
	unsigned short *buffer;
	unsigned int set_handwriting_area;	// 1: enable handwriting area 0: disable handwriting area
	unsigned int flag_for_ap;	// for application testing
};
typedef struct _update_area_t update_area_t;

//////////////////////////////////////////////////////////////////////////////////////////////////////
#endif	//__S3CFB_EPD_G1_H


/*==============================================================================
    0xFF00 --> is panel busy 
        input : none
        output: 1 byte busy_test
        
    0xFF02 --> update display area 
        input : struct PanelUpdateInfo
        output: none
        
    FBIO_AUO_UPDATE_DISPLAY_FULL 
        input : none
        output: none
        
    FBIO_AUO_UPDATE_DISPLAY_PARTIAL 
        input : struct _update_area_t
        output: none
        
    FBIO_AUO_RESTORE_DISPLAY 
        input : none
        output: none
        
    FBIO_AUO_SET_HANDWRITING_AREA 
        input : struct _update_area_t
        output: none 
==============================================================================*/

