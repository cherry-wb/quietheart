/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Implementation of common panel API factory.

==============================================================================*/

// config.h defines the panel interface:
// _PANEL_PVI_API_, _PANEL_PVI_API_
#include "config.h"

#include "panel.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>

// pvi panel init function.
#ifndef _PANEL_PVI_API_
static pfn_panel_init_t pfn_pvi_panel_init = 0;
#else
extern pfn_panel_init_t pfn_pvi_panel_init;
#endif

// auo panel init function.
#ifndef _PANEL_AUO_API_
static pfn_panel_init_t pfn_auo_panel_init = 0;
#else
extern pfn_panel_init_t pfn_auo_panel_init;
#endif

int panel_init(const char* name, panel_api_t * panel)
{
    assert(NULL!=name && NULL!=panel);
    
    // init panel api functions.
    if (!strcmp(name, "pvi"))
    {
        if (pfn_pvi_panel_init)
        {
            pfn_pvi_panel_init(panel);
            return 0;
        }
    }
    else
    if (!strcmp(name, "auo"))
    {
        if (pfn_auo_panel_init)
        {
            pfn_auo_panel_init(panel);
            return 0;
        }
    }

    printf("Error : %s screen is not supported!\n", name);
    return -1;
}

