/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Implementation of common functions of framebuffer.

==============================================================================*/

#include "fbcommon.h"

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>

#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

extern int g_b_silent;
extern int g_b_fbinfo;
extern int g_b_alpha;

// init fd, mapsize, fbw, fbh, fbmem
void fb_connect(const char* devpath, fb_data_t* fbdata)
{
    assert(devpath != NULL);
    assert(fbdata != NULL);
    
    //open
    assert(access(devpath, R_OK|W_OK) == 0);
    fbdata->fd = open(devpath, O_RDWR);
    assert(fbdata->fd != -1);

    //allocate mem for informations.
    struct fb_fix_screeninfo finfo;
    struct fb_var_screeninfo vinfo;
    memset(&vinfo, 0, sizeof(vinfo));
    memset(&finfo, 0, sizeof(finfo));

    //get fixed screen information
    if (fbdata->fd != -1 && ioctl(fbdata->fd, FBIOGET_FSCREENINFO, &finfo)!=0){
        assert(0);
    }

    //get variable screen information
    if (fbdata->fd != -1 && ioctl(fbdata->fd, FBIOGET_VSCREENINFO, &vinfo)!=0){
        assert(0);
    }

    //map mem
    fbdata->w       = vinfo.xres;
    fbdata->h       = vinfo.yres;
    fbdata->bpp     = vinfo.bits_per_pixel;
    fbdata->size    = fbdata->w * fbdata->h * fbdata->bpp / 8;
    fbdata->base    = (char*)mmap(0, fbdata->size, 
                            PROT_READ | PROT_WRITE, MAP_SHARED, fbdata->fd, 0);
    assert(fbdata->base != MAP_FAILED && fbdata->base != NULL);
    
    //log out some info
    int b_show = !g_b_silent && g_b_fbinfo;
    if(b_show)printf("device path           = %s\n",devpath);
    if(b_show)printf("finfo.smem_len        = %d\n",finfo.smem_len);
    if(b_show)printf("finfo.line_length     = %d\n",finfo.line_length);
    if(b_show)printf("vinfo.bits_per_pixel  = %d\n",vinfo.bits_per_pixel);
    if(b_show)printf("vinfo.xres            = %d\n",vinfo.xres);
    if(b_show)printf("vinfo.yres            = %d\n",vinfo.yres);
    if(b_show)printf("vinfo.grayscale       = %d\n",vinfo.grayscale);
    if(b_show)printf("vinfo.rotate          = %d\n",vinfo.rotate);
    if(b_show)printf("mapped address        = %p\n",fbdata->base);
    if(b_show)printf("mapped.memsize        = %d\n",fbdata->size);
}

// unmap buffer and close fb.
void fb_disconnect(fb_data_t* fbdata)
{
    //unmap mem
    assert(fbdata->base != NULL);
    munmap((char*)fbdata->base, fbdata->size);
    fbdata->size = 0;
    fbdata->base = 0;

    //close file
    assert(fbdata->fd != -1);
    close(fbdata->fd);
    fbdata->fd = 0;
}

//==============================================================================
// 32 bits RGB to Grayscale

//r = (argb >> 16) & 0xff
//g = (argb >> 8) & 0xff
//b = argb & 0xff
//return value is in [0,15]
inline uchar fb_argb32_to_gray4(int argb)
{
    return ((((argb>>16)&0xff)*11+((argb>>8)&0xff)*16+(argb & 0xff)*5)/32)>>4;
}
inline void fb_write_pixel_gray4(char *line_base, int offset, uchar gray, uchar alpha)
{
    if (255 == alpha)
    {
        char* pixel = line_base + offset*4/8;
        if ( offset & 1 ) {
            *pixel = (*pixel & 0xf0) | (gray & 0x0f);
        } else {
            *pixel = (*pixel & 0x0f) | ((gray & 0x0f) << 4);
        }
    }
    else
    if (0 == alpha)
    {
        // no need to do anything.
    }
    else
    {
        int g = gray;
        int a = alpha;
        char* pixel = line_base + offset*4/8;
        int pixel_old, pixel_new;
        if ( offset & 1 ) {
            pixel_old = *pixel & 0x0f;
            pixel_new = (pixel_old * (255-a) + g * a) >> 8;
            *pixel = (*pixel & 0xf0) | (pixel_new & 0x0f);
        } else {
            pixel_old = (*pixel & 0xf0) >> 4;
            pixel_new = (pixel_old * (255-a) + g * a) >> 8;
            *pixel = (*pixel & 0x0f) | ((pixel_new & 0x0f) << 4);
        }
    }
}


//==============================================================================
// 32 bits RGB to 8 bits Grayscale

inline uchar fb_argb32_to_gray8(int argb)
{
    return ((((argb>>16)&0xff)*11+((argb>>8)&0xff)*16+(argb & 0xff)*5)/32);
}
inline void fb_write_pixel_gray8(char *line_base, int offset, uchar gray, uchar alpha)
{
    uint g = gray;
    uint a = alpha;
    if (255 == alpha)
    {
        line_base[offset] = gray;
    }
    else
    if (0 == alpha)
    {
        // no need to do anything.
    }
    else
    {
        line_base[offset] = (line_base[offset] * (255-a) + g * a) >> 8;
    }
}


//==============================================================================
static inline void fb_write_gray_from_argb32(int dstbpp, void * dstbuf, int dx, int dy, int dw, int dh, int dstride, 
                                void * src32, int sx, int sy, int sw, int sh, int sstride)
{
    pfn_write_pixel_t       write_pixel = NULL;
    pfn_gray_from_rgb32_t   get_gray    = NULL;

    if (8 == dstbpp)
    {
        write_pixel = fb_write_pixel_gray8;
        get_gray    = fb_argb32_to_gray8;
    }
    else
    if (4 == dstbpp)
    {
        write_pixel = fb_write_pixel_gray4;
        get_gray    = fb_argb32_to_gray4;
    }
    else { return; }
    
    int  *src = (int *)src32;   // rgb32 is 4 bytes per pixel.
    char *dst = (char*)dstbuf;  // gray4 is 1/2 byte per pixel.
    int x,y;
    for(y=0; y<dh && y<sh; y++)
    {
        int  *src_line_base = src + (sy+y)*sstride;
        char *dst_line_base = dst + (dy+y)*dstride*dstbpp/8;
        for(x=0; x<dw && x<sw; x++)
        {
            write_pixel(dst_line_base, dx+x, get_gray(src_line_base[sx+x]), 
                        g_b_alpha ? (src_line_base[sx+x] >> 24 & 0xFF) : 255);
        }
    }
}

//==============================================================================
// common write function

// dstride : pixels per line of the screen buffer
// sstride : pixels per line of the source image
void fb_write_buf(fb_data_t* fbdata, int dx, int dy, int dw, int dh, int dstride, 
                void * src32, int sx, int sy, int sw, int sh, int sstride)
{
    fb_write_gray_from_argb32(fbdata->bpp,fbdata->base,dx,dy,dw,dh,dstride,
                                        src32,sx,sy,sw,sh,sstride);
}

// uchar gray : depends on bits per pixel.
void fb_paint_gray(int dstbpp, void * dstbuf, int dx, int dy, int dw, int dh, int dstride, uchar gray)
{
    pfn_write_pixel_t write_pixel = NULL;

    if (4 == dstbpp) { write_pixel = fb_write_pixel_gray4; }
    else if (8 == dstbpp) { write_pixel = fb_write_pixel_gray8; }
    else if (16 == dstbpp) { write_pixel = fb_write_pixel_gray8; }
    else
    {
        printf("Error : %d bpp is not supported now !\n", dstbpp);
        return;
    }
    
    char *dst = (char*)dstbuf;  // gray4 is 1/2 byte per pixel.
    int x,y;
    for(y=0; y<dh; y++)
    {
        char *dst_line_base = dst + (dy+y)*dstride*dstbpp/8;
        for(x=0; x<dw; x++)
        {
            write_pixel(dst_line_base, dx+x, gray, 255);
        }
    }
}

