/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    A easy used class for time logout.

==============================================================================*/

#ifndef _TIMELOG_H
#define _TIMELOG_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>

typedef struct timeval Timeval;
class TimeLog
{
public:
	inline static int getTime(Timeval *time) {
    	return gettimeofday(time, NULL);
    }
	inline static int start(Timeval *time) {
        getTime(&m_start);
        memcpy(&m_lastMarked, &m_start, sizeof(m_start));
        if(time) { memcpy(time, &m_start, sizeof(m_start)); }
        return m_start.tv_sec;
    }
	inline static int timeSinceStart(Timeval *time) {
		if(!m_start.tv_sec && !m_start.tv_usec && !m_lastMarked.tv_sec && !m_lastMarked.tv_usec){
			start(NULL);
		}
        Timeval tmpst, tmcur;
        if(-1==getTime(&tmcur)) { return -1; }
        timepassed(&tmpst, &m_start, &tmcur);
        memcpy(&m_lastMarked, &tmcur, sizeof(tmcur));
        if(time) { memcpy(time, &tmpst, sizeof(tmpst)); }
        return tmpst.tv_sec;
    }
	inline static int timeIncrement(Timeval *time) {
		if(!m_start.tv_sec && !m_start.tv_usec && !m_lastMarked.tv_sec && !m_lastMarked.tv_usec){
			start(NULL);
		}
        Timeval tminc, tmcur;
        getTime(&tmcur);
        timepassed(&tminc, &m_lastMarked, &tmcur);
        memcpy(&m_lastMarked, &tmcur, sizeof(tmcur));
        if(time) { memcpy(time, &tminc, sizeof(tminc)); }
        return tminc.tv_sec;
    }
	inline static char const *toString(const Timeval &time) {
        sprintf(m_strtime, "%5ld.%06ld", time.tv_sec, time.tv_usec);
        return &(m_strtime[0]);
    }
	inline static char const *strTimeSinceStart() {
        Timeval time;
        timeSinceStart(&time);
        return toString(time);
    }
	inline static char const *strTimeIncrement() {
        Timeval time;
        timeIncrement(&time);
        return toString(time);
    }
private:
	TimeLog(){}
	inline static int timepassed(Timeval *time, Timeval const *start, Timeval const *end) {
        if(!(time && start && end)) { return -1; }
        int borrow = (int)(end->tv_usec < start->tv_usec); // 0 or 1
        time->tv_usec = end->tv_usec - start->tv_usec + borrow * 1000000;
        time->tv_sec = end->tv_sec - start->tv_sec - borrow;
        return time->tv_sec;
    }
private:
	static Timeval m_start;
	static Timeval m_lastMarked;
	static char m_strtime[22];
};

Timeval TimeLog::m_start = {0,0};
Timeval TimeLog::m_lastMarked = {0,0};
char TimeLog::m_strtime[22] = {'\0'};

#endif // _TIMELOG_H

