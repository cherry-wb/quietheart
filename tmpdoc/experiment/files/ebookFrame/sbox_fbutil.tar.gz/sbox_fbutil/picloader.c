/*==============================================================================
             _   _  _____  _   _   _____  ___   _____  _____ 
            | \ | ||  ___|| | | | / ___/ / _ \ |  ___||_   _|
            |  \| || |__  | | | || (___ | / \ || |___   | |  
            | . ` ||  __| | | | | \__  \| | | ||  ___|  | |  
            | |\  || |___ | |_| | ___) || \_/ || |      | |  
            |_| \_||_____| \___/ |_____/ \___/ |_|      |_|  

                        Copyright (C) 2010 Neusoft.

[ Author ]
    zhaohp@neusoft.com

[ Description ]
    Implementation of picture loader. At present it only supports png format.

==============================================================================*/

#include "picloader.h"
#include <unistd.h>     // for open, close
#include <stdio.h>      // for printf
#include <stdlib.h>     // for lots of things
#include <fcntl.h>      // for open flags
#include <string.h>     // for memset
#include <png.h>        // for libpng

extern int g_b_silent;

//==============================================================================
//load png file data.
//return value need to be freed.
static char* read_png_from_file(const char* file_name, int *w, int *h)
{
    // 1. open the file.
    FILE *file = fopen(file_name, "rb");
    if(file == NULL) { return NULL; }

    // 2. create data structure for png reading.
    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    png_infop   info_ptr = png_create_info_struct(png_ptr);

    // 3. init io stream.
    png_init_io( png_ptr, file );

    // 4. read png header info.
    png_read_info( png_ptr, info_ptr );

    // 5. set some output parameters.
    // after png_set_* funcs, the output buf will be 4 bytes per pixel(ARGB8888).
    png_set_expand( png_ptr );
    //png_set_rgb_to_gray( png_ptr, 1 );
    png_set_gray_to_rgb( png_ptr );
    // bytes_per_pixel : if rgb, then 4; if grayscale, then 1;
    int bytes_per_pixel = 4;
    png_set_bgr( png_ptr );
    png_set_add_alpha( png_ptr, 0xFF, PNG_FILLER_AFTER );

    // 6. update the header info.
    png_read_update_info(png_ptr, info_ptr);

    // 6.5 now that we've got png info, so log some out.
    if(!g_b_silent)printf("png.path              = %s\n",file_name);
    if(!g_b_silent)printf("png.width             = %d\n",(int)info_ptr->width);
    if(!g_b_silent)printf("png.height            = %d\n",(int)info_ptr->height);
    if(!g_b_silent)printf("png.rowbytes          = %d\n",(int)info_ptr->rowbytes);
    if(!g_b_silent)printf("png.bit_depth         = %d\n",info_ptr->bit_depth);
    if(!g_b_silent)printf("png.channels          = %d\n",info_ptr->channels);
    if(!g_b_silent)printf("png.pixel_depth       = %d\n",info_ptr->pixel_depth);

    // 7. the return value of width and height.
    *w = info_ptr->width;
    *h = info_ptr->height;

    // 8. prepare some variables for reading image.
    // row_heads will be freed later in this func.
    png_bytepp  row_heads = (png_bytepp)malloc(info_ptr->height * sizeof(png_bytep));
    int         row_bytes = info_ptr->width * bytes_per_pixel;
    
    // malloc a big mem, this is the main return value.
    char* dest = (char*)malloc(info_ptr->height * row_bytes);
    
    // make row index.
    unsigned int i; //info_ptr->height is unsigned
    for( i=0; i < info_ptr->height; i++ ) {
        row_heads[i] = (png_bytep)(dest + row_bytes * i);
    }

    // 9. this is the real job to read the image.
    png_read_image( png_ptr, row_heads );

    // 10. clean
    free( row_heads );
    png_read_end( png_ptr, info_ptr );
    png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
    fclose(file);

    // 12. return
    return dest;
}


//==============================================================================
//externel api

//return value need to be freed.
char* pic_load_from_file(const char* file_name, int *w, int *h)
{
    //XXX should parse image format automatically, by filename extension.
    // now only png is supported.
    return read_png_from_file(file_name, w, h);
}

//just release the buffer.
void pic_drop_buf(char* buf)
{
    free(buf);
}

