rm -rf tmp_build/ Makefile xinputmethod




