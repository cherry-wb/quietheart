#include "winManage.h"

gint main(gint argc, gchar *argv[])
{
	unsigned activeWinId = 0;
	Display *disp;
	if (! (disp = XOpenDisplay(NULL)))
	{
		fputs("Cannot open display.\n", stderr);
		return ;
	}
	Window win = get_active_window(disp);
	gchar *class = get_window_class(disp, win); 
	if(g_strcasecmp(class, "") == 0)
	{//如果当前的窗口是桌面

	}
	else
	{//如果不是桌面则切换到桌面
	}
	g_free(class);
	return 0;
}
