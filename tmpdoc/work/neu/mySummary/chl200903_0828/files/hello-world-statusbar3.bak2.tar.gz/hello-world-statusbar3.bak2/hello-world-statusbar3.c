/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */

/* Hildon includes */
#include <hildon/hildon-note.h>
#include <hildon/hildon-banner.h>
#include <hildon/hildon-sound.h>
#include <hildon/hildon-defines.h>
#include <libhildondesktop/libhildondesktop.h>

#include <log-functions.h>
#include <libosso.h>
#include <osso-log.h>

/* GTK includes */
#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdkpixbuf.h>

/* Systems includes */
#include <string.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/*lkadd{*/
/*注意这个宏的值如果是1那么每当离开entry的时候焦点就会自动离开*/
#define MY_FOCUS_AUTOMOVE 0
/*lkadd}*/
#include "hello-world-statusbar3.h"

HD_DEFINE_PLUGIN(HildonStatusBarHelloWorld3,
		 hildon_status_bar_helloworld,
	       	 STATUSBAR_TYPE_ITEM);

#define HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(x) \
	    (G_TYPE_INSTANCE_GET_PRIVATE((x), \
                                         hildon_status_bar_helloworld_get_type(), \
                                         HildonStatusBarHelloWorld3Private));

static void hildon_status_bar_helloworld_finalize(GObject *object);

static void hildon_status_bar_helloworld_class_init(
		HildonStatusBarHelloWorld3Class *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS(klass);
    object_class->finalize = hildon_status_bar_helloworld_finalize;
    g_type_class_add_private(klass, sizeof(HildonStatusBarHelloWorld3Private));
}

static void set_helloworld_icon(const gchar *name, HildonStatusBarHelloWorld3Private *info)
{
    GtkIconTheme *icon_theme;
    GdkPixbuf    *pixbuf;

    icon_theme = gtk_icon_theme_get_default();

    pixbuf = (name != NULL) ? gtk_icon_theme_load_icon(icon_theme, name,
                                                       HILDON_STATUS_BAR_HELLOWORLD_ICON_SIZE,
                                                       GTK_ICON_LOOKUP_NO_SVG, NULL) : NULL;

    gtk_image_set_from_pixbuf(GTK_IMAGE(info->icon), pixbuf);

    if (pixbuf != NULL)
        g_object_unref(pixbuf);
}

static void hildon_status_bar_helloworld_finalize(GObject *object)
{
    HildonStatusBarHelloWorld3Private *info = HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(object);

    osso_deinitialize(info->osso);

    LOG_CLOSE();

    G_OBJECT_CLASS(g_type_class_peek_parent(G_OBJECT_GET_CLASS(object)))->finalize(object);
}
/*lkadd*/

void my_entry_pressed(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
  g_print("press my entry!\n");
  GtkWidget *p;
  gboolean ret;
  p = gtk_widget_get_parent(
		  gtk_widget_get_parent(gtk_widget_get_parent(GTK_WIDGET(data))));
  /*from panel-window.c button press*/
  gtk_window_set_accept_focus (GTK_WINDOW(p), TRUE);/*lkadd*/
  g_signal_emit_by_name(G_OBJECT(p), "focus-in-event", NULL, &ret);/*lkadd*/
  //gdk_pointer_ungrab(GDK_CURRENT_TIME);
  gdk_keyboard_grab (GTK_WIDGET (p)->window, 
		       FALSE, GDK_CURRENT_TIME);/*lkadd*/
  //gdk_keyboard_ungrab (GDK_CURRENT_TIME);
  //gtk_grab_remove(GTK_WIDGET (p));
  //hildon_desktop_panel_stop_grab (p,
//			 GDK_CURRENT_TIME);
  //gtk_window_set_accept_focus (GTK_WINDOW(p), FALSE);/*lkadd*/
}
#if MY_FOCUS_AUTOMOVE == 1
gboolean leave_entry(GtkWidget *widget, GdkEventCrossing *event,gpointer data)
{
	g_print("leave the entry\n");
  //gdk_pointer_ungrab(GDK_CURRENT_TIME);
  gdk_keyboard_ungrab (GDK_CURRENT_TIME);
	return FALSE;
}
gboolean enter_entry(GtkWidget *widget, GdkEventCrossing *event,gpointer data)
{
	g_print("entry the entry\n");
  GtkWidget *p;
  p = gtk_widget_get_parent(gtk_widget_get_parent(gtk_widget_get_parent(GTK_WIDGET(data))));
  gdk_keyboard_grab (GTK_WIDGET (p)->window, 
		       FALSE, GDK_CURRENT_TIME);/*lkadd*/
	return FALSE;
}
#endif
/*lkadd*/
static void hildon_status_bar_helloworld_init(HildonStatusBarHelloWorld3 *helloworld)
{
    HildonStatusBarHelloWorld3Private *info = 
        HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(helloworld);

    ULOG_OPEN("hildon-sb-helloworld");

    g_return_if_fail(info);

    set_helloworld_icon("hello-world", info);

	/*lkadd{*/
	info->entry = gtk_entry_new();
    g_signal_connect(G_OBJECT(info->entry), "button-press-event",
                     G_CALLBACK(my_entry_pressed), helloworld);/*lkupdate,add signal to the statusbar button*/
#if MY_FOCUS_AUTOMOVE ==1
    g_signal_connect(G_OBJECT(info->entry), "leave-notify-event",
                     G_CALLBACK(leave_entry), NULL);/*lkupdate,add signal to the statusbar button*/
    g_signal_connect(G_OBJECT(info->entry), "enter-notify-event",
                     G_CALLBACK(enter_entry), helloworld);/*lkupdate,add signal to the statusbar button*/
#endif
	gtk_entry_set_text(GTK_ENTRY(info->entry), "test");
    gtk_container_add(GTK_CONTAINER(helloworld), info->entry);
	/*lkadd}*/
    /* Initialize osso */
    info->osso = osso_initialize("hildon_sb_helloworld", "1.0", FALSE, NULL);
    if (!info->osso)
        ULOG_WARN("%s: error while initializing osso\n", __FUNCTION__);

    gtk_widget_show_all(GTK_WIDGET(helloworld));
}
