/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>

#include <glib.h>
#include <gtk/gtk.h>

#include <libhildondesktop/libhildondesktop.h>

#include "hello-world-home.h"
#include "libhelloworld.h"


HD_DEFINE_PLUGIN (HelloHomePlugin, hello_home_plugin, HILDON_DESKTOP_TYPE_HOME_ITEM);

gint x = 50;
gint y = 50;
struct MyTData
{
	GtkWidget *fix;
	GtkWidget *button;
};
struct MyTData tmp;
gint t;
/* This callback function moves the button to a new position
 * in the Fixed container. */
static void stop_auto_move(GtkWidget *widget,
		gpointer data)
{
	/*g_print("in stop function t=%d\n",(gint)data);*/
	g_source_remove(*((gint*)data));
}
static gint auto_move_button(gpointer data)
{
	x = (x + 10) % 800;
	y = (y + 50) % 480;
	gtk_fixed_move(GTK_FIXED(((struct MyTData*)data)->fix), ((struct MyTData*)data)->button, x, y);
	/*g_print("ok\n");*/
	return TRUE;
}

static gboolean
transparent_expose (GtkWidget      *widget,
                    GdkEventExpose *event)
{
g_print("here,transparent_expose");
  cairo_t *cr;
  cr = gdk_cairo_create (widget->window);
  cairo_set_operator (cr, CAIRO_OPERATOR_CLEAR);
  gdk_cairo_region (cr, event->region);

 cairo_clip (cr);
  /* composite, with a 50% opacity */
  cairo_set_operator (cr, CAIRO_OPERATOR_OVER);
  cairo_paint_with_alpha (cr, 0);

  //cairo_fill (cr);
  cairo_destroy (cr);
  return FALSE;
}


static void
hello_home_plugin_init (HelloHomePlugin *home_plugin)
{
  GtkWidget *button;
  GtkWidget *fixed;/*lkupdate*/
  GtkWidget *moveButton;
  GtkWidget *subWindow;
  subWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_opacity(GTK_WINDOW(subWindow), 0.5);
  gtk_window_set_decorated(GTK_WINDOW(subWindow), FALSE);
  fixed = gtk_fixed_new ();/*lkupdate*/
  button = hello_world_button_new (10);
  gtk_container_add(GTK_CONTAINER(home_plugin), subWindow);
  gtk_container_add (GTK_CONTAINER (subWindow), fixed);
  gtk_fixed_put (GTK_FIXED (fixed), button, 50, 50);
  g_signal_connect (button, "clicked",
		    G_CALLBACK (hello_world_dialog_show),
		    NULL);
  moveButton = gtk_button_new_with_label("Stop!!");
  gtk_fixed_put(GTK_FIXED(fixed), moveButton, 200,200);
  tmp.fix = fixed;
  tmp.button = moveButton;
  t = g_timeout_add(500, auto_move_button, &tmp);
 /*g_print("out function t=%d",t);*/
  g_signal_connect(G_OBJECT(moveButton), "clicked",
		  G_CALLBACK(stop_auto_move),&t);
  gtk_widget_show(button);

  gtk_widget_show_all (fixed);
  /* Set the resizing behavior */
  hildon_desktop_home_item_set_resize_type (HILDON_DESKTOP_HOME_ITEM (home_plugin),
                                            HILDON_DESKTOP_HOME_ITEM_RESIZE_BOTH);

}

static void
hello_home_plugin_class_init (HelloHomePluginClass *class)
{
}

