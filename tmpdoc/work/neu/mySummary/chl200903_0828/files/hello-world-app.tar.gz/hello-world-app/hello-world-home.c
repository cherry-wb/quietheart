/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>

#include <glib.h>
#include <gtk/gtk.h>

#include <libhildondesktop/libhildondesktop.h>

#include "hello-world-home.h"
//#include "libhelloworld.h"


HD_DEFINE_PLUGIN (HelloHomePlugin, hello_home_plugin, HILDON_DESKTOP_TYPE_HOME_ITEM);

/*lkadd
gint x = 50;
gint y = 50;
struct MyTData
{
	GtkWidget *fix;
	GtkWidget *button;
};
struct MyTData tmp;
gint t;
*/
/* This callback function moves the button to a new position
 * in the Fixed container. */
/*lkadd
static void stop_auto_move(GtkWidget *widget,
		gpointer data)
{
	g_source_remove(*((gint*)data));
}

static gint auto_move_button(gpointer data)
{
	x = (x + 10) % 800;
	y = (y + 50) % 480;
	gtk_fixed_move(GTK_FIXED(((struct MyTData*)data)->fix), ((struct MyTData*)data)->button, x, y);
	return TRUE;
}

static gboolean
transparent_expose (GtkWidget      *widget,
                    GdkEventExpose *event)
{
g_print("here,transparent_expose");
  cairo_t *cr;
  cr = gdk_cairo_create (widget->window);
  cairo_set_operator (cr, CAIRO_OPERATOR_CLEAR);
  gdk_cairo_region (cr, event->region);

 cairo_clip (cr);
 cairo_set_operator (cr, CAIRO_OPERATOR_OVER);
 cairo_paint_with_alpha (cr, 0);

  //cairo_fill (cr);
  cairo_destroy (cr);
  return FALSE;
}
*/

static void
hello_home_plugin_init (HelloHomePlugin *home_plugin)
{
  GtkWidget *entry;
  GtkWidget *fixed;/*lkupdate*/
  GtkWidget *moveButton;
  //GtkWidget *subWindow;
//GdkScreen *screen;
 // GdkColormap *rgba;
  //subWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  //gtk_window_set_opacity(GTK_WINDOW(subWindow), 0.5);
  //gtk_window_set_decorated(GTK_WINDOW(subWindow), FALSE);
  fixed = gtk_fixed_new ();/*lkupdate*/

//screen = gtk_widget_get_screen (fixed);
 // rgba = gdk_screen_get_rgba_colormap (screen);
 // gtk_widget_set_colormap (fixed, rgba);
//gtk_widget_set_app_paintable (GTK_WIDGET (fixed), TRUE);
 // g_signal_connect (fixed, "expose-event",
   //                 G_CALLBACK (transparent_expose), NULL);

  entry = gtk_entry_new();
  gtk_entry_set_text(GTK_ENTRY(entry), "test_home");
  //gtk_container_add(GTK_CONTAINER(home_plugin), subWindow);
  gtk_container_add (GTK_CONTAINER (home_plugin), fixed);
  //gtk_container_add (GTK_CONTAINER (home_plugin), entry);
  gtk_fixed_put (GTK_FIXED (fixed), entry, 50, 50);
  //g_signal_connect (button, "clicked",
	//	    G_CALLBACK (hello_world_dialog_show),
	//	    NULL);
  moveButton = gtk_button_new_with_label("Stop!!");
  gtk_fixed_put(GTK_FIXED(fixed), moveButton, 200,200);
  //tmp.fix = fixed;
  //tmp.button = moveButton;
  //t = g_timeout_add(500, auto_move_button, &tmp);
 /*g_print("out function t=%d",t);*/
  //g_signal_connect(G_OBJECT(moveButton), "clicked",
	//	  G_CALLBACK(stop_auto_move),&t);
  //gtk_widget_show(entry);

  gtk_widget_show_all (fixed);
//gdk_window_set_composited (fixed->window, TRUE);
  /* Set the resizing behavior */
  hildon_desktop_home_item_set_resize_type (HILDON_DESKTOP_HOME_ITEM (home_plugin),
                                            HILDON_DESKTOP_HOME_ITEM_RESIZE_BOTH);

}

static void
hello_home_plugin_class_init (HelloHomePluginClass *class)
{
}

