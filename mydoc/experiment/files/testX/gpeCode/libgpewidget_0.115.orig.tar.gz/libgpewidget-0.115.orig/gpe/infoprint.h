#ifndef __GPE_INFOPRINT_H
#define __GPE_INFOPRINT_H

extern void gpe_popup_infoprint (Display *dpy, char *s);

#endif
