/* ============================ include headers start =================*/
//#include <errno.h>
//#include <sys/types.h>
//#include <netinet/in.h>
//#include <sys/socket.h>
//#include <sys/wait.h>
#include 	<stdio.h>			/* for printf() */
#include 	<stdlib.h>			/* for exit() */
#include 	<string.h>			/* for bzero() */
#include 	<arpa/inet.h>		/* for inet_ntoa() */
#include 	<unistd.h>			/* for close() */
#include 	<assert.h>			/* for assert() */
#include 	<sys/stat.h>		/* for mkfifo(), S_IRUSR, etc. */
#include 	<sys/wait.h> 		/* for waitpid() */
#include 	<fcntl.h> 			/* for open(), O_RDONLY */
#include 	<pthread.h> 		/* for pthread_create(), etc. */
#include 	<errno.h> 			/* for errno. */
#include 	<signal.h> 			/* for signal(). */

#include 	"suu_common.h"
#include 	"sysinfo.h"
#include 	"socket_util.h"
/* ============================ include headers end ===================*/

#define 	STR_MSG_FIFO 		"svrmsg.fifo"
#define 	NUM_CMDSTR_SIZE 	(256)

/* fifo name */
#define 	STR_KN_IMG 			"kernel.img"
#define 	STR_RM_IMG 			"ramfs.img"
#define 	STR_RF_FIFO 		"rootfs.fifo"
/* default device path */
#define 	STR_DF_KN_DEV 		"/dev/mtd2"
#define 	STR_DF_RM_DEV 		"/dev/mtd3"
#define 	STR_DF_RF_DEV 		"/dev/mtd0"

#define 	NUM_SVR_MSGBUF_SIZE 	(10)


/* ============================ typedef start =========================*/
// simple remote procedure calling function.
// there is no socket operation within srpc_func.
typedef int (*srpc_func)(int sock_cln, const byte* input, const int insize, byte** output, int* outsize);
/* ============================ typedef end ===========================*/

/* ============================ const and static start ================*/
static char * const usage_str = 
			"\t-p <value> :  The server's port. (default is 3333)\n"
			"\t-k <value> :  The kernel's device. (default is " STR_DF_KN_DEV ")\n"
			"\t-r <value> :  The ramfs's device. (default is " STR_DF_RM_DEV ")\n"
			"\t-f <value> :  The rootfs's device. (default is " STR_DF_RF_DEV ")\n"
			"\t-h <value> :  Help\n";

static const char* 	svrversion = "Standalone Update Utility (SED) ver 0.01, NEUSOFT 2009.";
static srpc_func 	service_list[_SRPC_ID_MAX];

static int 		sock_lsn = -1;
static int 		sock_cln = -1;

static int 		port 	= 0;
static char* 	kndev 	= NULL;
static char* 	rmdev 	= NULL;
static char* 	rfdev 	= NULL;
static char* 	call 	= NULL;
/* ============================ const and static end ==================*/


/* ============================ functions =============================*/

extern int ubi_fmt_set_msg_fifo(char * fname);
extern int ubiformat(int argc, char * const argv [ ]);
extern int flash_unlock(int argc, char * argv [ ]);
extern int fla_set_msg_fifo(char * fname);
extern int flashcp(int argc, char * argv [ ]);

static void svr_cleanup (void)
{
	printf("\n\n"_PROM_S"cleaning up ... ");
	if (sock_cln > 0){ close (sock_cln); }
	if (sock_lsn > 0){ close (sock_lsn); }
	sock_cln = sock_lsn = -1;
	system("rm -rf "STR_MSG_FIFO" "STR_RF_FIFO" "STR_KN_IMG);
	printf("done.\n\n");
}

void * run_flashcp(void * argv)
{
	char** arglst = (char**)argv;
	int i; // how many args.
	for(i=0; arglst[i]!=NULL; i++);
	
	// run the ubiformat routine.
	fla_set_msg_fifo(STR_MSG_FIFO);
	printf("%s %s %s %s" _NL, arglst[0], arglst[1], arglst[2], arglst[3]);
	int rtval = flashcp(i, arglst);
		
	// this result value will be waited and parsed later.
	return (void*)rtval;
}


int burn_flash(char* dev, char* img)
{
	// some variables throughout this routine.
	int 	result 		= 0;
	int 	rcv 		= 0;
	int 	fsize 		= 0;
	int 	szblock 	= 0;
	char* 	cmdstr 		= NULL;
	char* 	rcvbuf 		= NULL;
	pthread_t 	thid 		= 0;

	// receive some globle info of the file.
	if((rcv = recv_easy(sock_cln, &fsize, sizeof(int), MSG_WAITALL)) == -1){ return -1; }
	// receive the buffer size
	if((rcv = recv_easy(sock_cln, &szblock, sizeof(int), MSG_WAITALL)) == -1){ return -1; }
	// allocate a buffer, using the given size.
	rcvbuf = (char*)malloc(szblock);
	
	// open the file and write the received data into it.
	FILE* file = fopen(img, "w");
	while(1)
	{
		// this recv_easy() must NOT set flag MSG_WAITALL !!
		if((rcv = recv_easy(sock_cln, rcvbuf, szblock, 0)) == -1){ return -1; }
	
		// write the data we received to the fifo.
		if(fwrite(rcvbuf, 1, rcv, file) != rcv)
		{
			fclose(file);
			return -1;
		}
	
		// calculate the remaining size.
		fsize -= rcv;
		if(fsize == 0){ break; } // break if all data has been received.
		if(fsize < 0){ return -1; }
	}
	fclose(file);
	
	// prepare params for flash_unlock().
	cmdstr = (char*)malloc(NUM_CMDSTR_SIZE*sizeof(char));
	sprintf(cmdstr, "flash_unlock %s", dev);
	printf("%s" _NL, cmdstr);
	char* arglist_funlock[2];
	arglist_funlock[0] = strtok(cmdstr, " ");
	int i;
	for(i=1; i<2; arglist_funlock[i] = strtok(NULL, " "), i++);
	
	// make a fifo for ubiformat message.
	mkfifo(STR_MSG_FIFO, (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH));

	// unlock the flash.
	if(0==(result=flash_unlock(2, arglist_funlock)))
	{	// unlock the flash successfully.
		// prepare params for flashcp().
		sprintf(cmdstr, "flashcp -v %s %s", img, dev);
		//printf("\n%s" _NL, cmdstr);
		char* arglist_fcp[5];
		arglist_fcp[0] = strtok(cmdstr, " ");
		for(i=1; i<4; arglist_fcp[i] = strtok(NULL, " "), i++);
		arglist_fcp[4] = NULL;
		
		// run ubiformat in another thread.
		pthread_create(&thid, NULL, run_flashcp, arglist_fcp);

		//=============================> sending erase, write, verify progress percent start.
		char* 	mbuf = (char*)malloc(NUM_SVR_MSGBUF_SIZE);
		int 	step;
		char 	flag;
		int 	goodluck = 1;
		for(step=1; goodluck && step<=3; step++)
		{
			switch(step){
				case 1:				// step 1
					flag = 'e'; 	// erase progress
					printf(_NL _PROM_S "Start to erase flash." _NL);
					break;
				case 2:				// step 2
					flag = 'w'; 	// write progress
					printf(_NL _PROM_S "Start to write flash." _NL);
					break;
				case 3:				// step 3
					flag = 'v'; 	// verify progress
					printf(_NL _PROM_S "Start to verify flash." _NL);
					break;
				default: break;
			}
			while(1)
			{
				memset(mbuf, 0, NUM_SVR_MSGBUF_SIZE);
				
				int fdmsg = open(STR_MSG_FIFO, O_RDONLY);
				int rdn = read(fdmsg, mbuf, NUM_SVR_MSGBUF_SIZE);
				close(fdmsg);

				if( *mbuf == '!' ){ goodluck = 0; break; }
				if( *mbuf != flag ){ continue; }
				if( send_easy(sock_cln, mbuf, rdn, 0) < rdn ){ goodluck = 0; break; }
				if( 100==atoi(mbuf+1) ){ break; }
			}
		}
		if(mbuf!=NULL){ free(mbuf); mbuf=NULL; }
		//=============================> sending erase, write, verify progress percent done.
		
		// flashcp() would use the fifo we created.
		// so we won't remove the fifo until ubiformat() is done.
		pthread_join(thid, (void**)(&result));
	}
	else
	{
		fprintf(stderr, "Update Kernel: Error! flash_unlock() failed!\n");
	}
	
	// remove the temp image file and msg fifo.
	sprintf(cmdstr, "rm -f %s %s", img, STR_MSG_FIFO);
	system(cmdstr);
	
	// free some buffers.
	if(cmdstr!=NULL){ free(cmdstr); cmdstr=NULL; }
	if(rcvbuf!=NULL){ free(rcvbuf); rcvbuf=NULL; }

	return result;
}

int srpc_burn_kernel(int sock_cln, const byte* input, const int insize, byte** output, int* outsize)
{
	printf(_PROM_S "Start to update kernel." _NL);

	int result = burn_flash(kndev, STR_KN_IMG);
	
	printf(_PROM_S "Finish updating kernel." _NL);
	return result;
}


int srpc_burn_ramfs(int sock_cln, const byte* input, const int insize, byte** output, int* outsize)
{
	printf(_PROM_S "Start to update ramfs." _NL);

	int result = burn_flash(rmdev, STR_RM_IMG);

	printf(_PROM_S "Finish updating ramfs." _NL);
	return result;
}

static volatile int ubi_is_err = 0;

void * run_ubiformat(void * argv)
{
	char** arglst = (char**)argv;
	int i; // how many args.
	for(i=0; arglst[i]!=NULL; i++);
	
	// Redirection: we need to redirect the fifo as stdin for ubiformat.
	int fd_fifo = open(STR_RF_FIFO, O_RDONLY);
	assert(fd_fifo!=-1);
	
	// copy the stdin fd, because we want to change it back when ubiformat is done.
	int fd_stdin_cp = dup(STDIN_FILENO);
	dup2(fd_fifo, STDIN_FILENO);
	close(fd_fifo);
	
	// run the ubiformat routine.
	ubi_fmt_set_msg_fifo(STR_MSG_FIFO);
	printf("%s %s %s %s %s %s" _NL, arglst[0], arglst[1], arglst[2], arglst[3], arglst[4], arglst[5]);
	int rtval = ubiformat(i, arglst);
	
	// change the stdin fd back to real stdin.
	dup2(fd_stdin_cp, STDIN_FILENO);
	// close the temp copy of the stdin.
	close(fd_stdin_cp);

	if(rtval<0)
	{
		ubi_is_err = 1;
		int fd = open(STR_RF_FIFO, O_RDONLY|O_NONBLOCK);
		if(fd!=-1)
		{
			char* tmpbuf = (char*)malloc(4096);
			int rdn = 0;
			do
			{
				/* If this thread is off, no thread will read the rootfs image fifo.
				   So the main thread might be blocked at programming the flash, 
				   while writing that image fifo. So the process will blocked forever. 
				   Here we set a error flag 'ubi_is_err', then read the fifo forward, 
				   so that the main thread would go on and finally see the flag, then 
				   the main thread would quit from the writing loop. */
				rdn = read(fd, tmpbuf, 4096);
			}
			while(rdn!=0 && rdn!=-1);
			free(tmpbuf);
		}
		printf(_PROM_S "ubiformat() returns %d\n", rtval);
	}
	
	// this result value will be waited and parsed later.
	return (void*)rtval;
}


int srpc_burn_rootfs(int sock_cln, const byte* input, const int insize, byte** output, int* outsize)
{
	printf(_PROM_S "Start to update rootfs." _NL);
	
	// some variables throughout this routine.
	int 		result 		= 0;
	int 		fsize 		= 0;
	int 		szblock 	= 0;
	char* 		cmdstr 		= NULL;
	char* 		rcvbuf 		= NULL;
	char* 		mbuf		= NULL;
	pthread_t 	thid 		= 0;
	int 		goodluck 	= 1;

	// make a fifo for fs image.
	mkfifo(STR_RF_FIFO, (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH));
	// make a fifo for ubiformat message.
	mkfifo(STR_MSG_FIFO, (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH));

	// receive size of the file and the buffer size.
	if(recv_easy(sock_cln, &fsize, sizeof(int), MSG_WAITALL) == -1){ return -1; }
	if(recv_easy(sock_cln, &szblock, sizeof(int), MSG_WAITALL) == -1){ return -1; }
	
	// allocate a buffer, using the given size.
	rcvbuf 	= (char*)malloc(szblock);
	cmdstr 	= (char*)malloc(NUM_CMDSTR_SIZE*sizeof(char));
	mbuf 	= (char*)malloc(NUM_SVR_MSGBUF_SIZE);
	assert( cmdstr != NULL && rcvbuf != NULL && mbuf != NULL );
	
	// build the command string, then parse the params for ubiformat().
	sprintf(cmdstr, "ubiformat %s -f - -S %d", rfdev, fsize);
	char* arglist[7];
	arglist[0] = strtok(cmdstr, " ");
	int i;
	for(i=1; i<6; arglist[i] = strtok(NULL, " "), i++);
	arglist[6] = NULL;
	
	// run ubiformat in another thread.
	pthread_create(&thid, NULL, run_ubiformat, arglist);
	// open image fifo before blocking to receive messages from msg fifo.
	// because ubiformat() will open it to read in another thread, we dont want it blocked.
	FILE* file = fopen(STR_RF_FIFO, "w");
	assert( file!=NULL );

	//===============================================> sending scan progress percent start.
	if(goodluck){ printf(_NL _PROM_S "Start to scan flash." _NL); }
	while(goodluck)
	{
		int fdmsg = open(STR_MSG_FIFO, O_RDONLY);
		int rdn = read(fdmsg, mbuf, NUM_SVR_MSGBUF_SIZE);
		close(fdmsg);
		if( *mbuf == '!' ){	goodluck = 0; break; }
		if( *mbuf != 's' ){ continue; }
		if(send_easy(sock_cln, mbuf, rdn, 0) < rdn)
		{
			pthread_cancel(thid);
			goodluck = 0;
			break;
		}
		if(100==atoi(mbuf+1))
		{
			printf(_NL _PROM_S "scanning flash done!" _NL);
			break;
		}
	}
	//===============================================> sending scan progress percent done.
	
	//===============================================> programming flash start.
	if(goodluck){ printf(_PROM_S "Start to program flash. %s" _NL, goodluck?"goodluck":""); }
	while(goodluck)
	{	// receive the data and write to the fifo.
		// this recv_easy() must NOT set flag MSG_WAITALL !!
		int rcv = recv_easy(sock_cln, rcvbuf, szblock, 0);
		// the 'if(fsize == 0){ break; }' statement ensures rcv cannot be 0.
		if( rcv == -1 || rcv == 0)
		{
			pthread_cancel(thid);
			goodluck = 0;
			break;
		}
		if(ubi_is_err || fwrite(rcvbuf, 1, rcv, file) != rcv)
		{
			pthread_cancel(thid);
			goodluck = 0;
			break;
		}
	
		// calculate the remaining size.
		fsize -= rcv;
		if(fsize == 0){ break; } // break if all data has been received.
		if(fsize < 0){ assert(0); }
	}
	fclose(file);
	//===============================================> programming flash done.

	//===============================================> sending format progress percent start.
	if(goodluck){ printf(_NL _PROM_S "Start to format flash. %s" _NL, goodluck?"goodluck":""); }
	while(goodluck)
	{
		int fdmsg = open(STR_MSG_FIFO, O_RDONLY);
		int rdn = read(fdmsg, mbuf, NUM_SVR_MSGBUF_SIZE);
		close(fdmsg);
		if( *mbuf == '!' ){	goodluck = 0; break; }
		if( *mbuf != 'f' ){ continue; }
		if(send_easy(sock_cln, mbuf, rdn, 0) < rdn)
		{
			pthread_cancel(thid);
			goodluck = 0;
			break;
		}
		if(100==atoi(mbuf+1))
		{
			printf(_NL _PROM_S "formatting flash done!" _NL);
			break;
		}
	}
	//===============================================> sending format progress percent done.

	// ubiformat() would use the fifo we created.
	// so we won't remove the fifo until ubiformat() is done.
	pthread_join(thid, (void**)(&result));
	
	// remove 2 fifos.
	sprintf(cmdstr, "rm -f %s %s", STR_RF_FIFO, STR_MSG_FIFO);
	system(cmdstr);

	// free some buffers.
	if(mbuf!=NULL)  { free(mbuf);   mbuf=NULL; }
	if(cmdstr!=NULL){ free(cmdstr); cmdstr=NULL; }
	if(rcvbuf!=NULL){ free(rcvbuf); rcvbuf=NULL; }

	printf(_PROM_S "Finish updating rootfs." _NL);
	return result;
}


// get server info.
int srpc_get_server_info(int sock_cln, const byte* input, const int insize, byte** output, int* outsize)
{
	char* 	buffer 			= NULL;

	/*
	sysinfo_gethostname(buffer, block-size);
	len = strlen(buffer);
	buffer += len;
	size += len;
	
	sprintf(buffer, _NL);
	len = strlen(buffer);
	buffer += len;
	size += len;

	sysinfo_getversion(buffer, block-size);
	len = strlen(buffer);
	buffer += len;
	size += len;
	
	sprintf(buffer, _NL);
	len = strlen(buffer);
	buffer += len;
	size += len;
	//*/

	sysinfo_getmtd(&buffer, NULL);
	
	//==> param buffer done.

	*output = (byte*)buffer;
	*outsize = strlen(buffer)+1; // add the NUL char.
	
	return 0;
}


int init_server(void)
{
	// init the service list.
	service_list[_SRPC_ID_UPDATE_KERNEL] 	= srpc_burn_kernel;
	service_list[_SRPC_ID_UPDATE_RAMFS] 	= srpc_burn_ramfs;
	service_list[_SRPC_ID_UPDATE_ROOTFS] 	= srpc_burn_rootfs;
	service_list[_SRPC_ID_GET_SVR_INFO]     = srpc_get_server_info;

	int						sock_lsn;	/* listen socket */
	struct sockaddr_in		local_addr;

	// build a socket to listen to.
	sock_lsn = socket(AF_INET, SOCK_STREAM, 0); 
	if(sock_lsn == -1){return -1;}

	local_addr.sin_family		= AF_INET;
	local_addr.sin_port			= htons(SERVPORT);
	local_addr.sin_addr.s_addr	= INADDR_ANY;
	memset(&(local_addr.sin_zero), 0, sizeof(local_addr.sin_zero));

	// bind the socket.
	if(bind(sock_lsn, (struct sockaddr*)&local_addr, sizeof(struct sockaddr)) == -1){return -1;}
	if(listen(sock_lsn, MAXACCESS) == -1){return -1;}

	// return the socket.
	return sock_lsn;
}


// accept client socket connection.
// welcome : send server info to client, first size, then content.
// return the socket connected with client.
int welcome(int sock_lsn, const char* str)
{
	// show client ip and port.
	int 					sock_fd = -1;
	struct sockaddr_in		remot_addr;
	unsigned int 			sin_size = sizeof(struct sockaddr_in);
	if((sock_fd = accept(sock_lsn, (struct sockaddr *)&remot_addr, &sin_size)) == -1){return -1;}
	printf("Accepted a connection from [ %s : %d ]" _NL _NL, inet_ntoa(remot_addr.sin_addr), ntohs(remot_addr.sin_port));
	//==> show client done.

	// send server info to client.
	int 	infosz	= strlen(str)+1;
	if(send_easy(sock_fd, &infosz, sizeof(int), 0) < sizeof(int)){return -1;}
	if(send_easy(sock_fd, str, infosz, 0) < infosz){return -1;}
	//==> send server info done.

	return sock_fd;
}


static void usage( const char* appname )
{
	printf("Usage: %s [options]" _NL, appname);
	printf("%s", usage_str);
}


/********************************************************************
 * Parce the command line options of this program.
 ********************************************************************/
int svr_parse_opt(int argc,char * const argv[])
{
	int i;
	for(i=1; i< argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(2!=strlen(argv[i]))
			{
				usage(argv[0]);
				return ERROR_OPT;
			}
			switch(argv[i][1])
			{
				case 'p':
					port = atoi(argv[++i]);
					if(port<1024 || port > 65535)
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
				case 'k':
					kndev = argv[++i];
					if(kndev == NULL || kndev[0] == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
				case 'r':
					rmdev = &(argv[++i][0]);
					if(rmdev == NULL || *rmdev == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
				case 'f':
					rfdev = &(argv[++i][0]);
					if(rfdev == NULL || *rfdev == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
				case 'c':
					call = argv[++i];
					break;

				case 'h':
				default:
					usage(argv[0]);
					return ERROR_OPT;
			}
		}
		else
		{
			usage(argv[0]);
			return ERROR_OPT;
		}
	}

	if(port == 0)		{ port = SERVPORT; }
	if(kndev == NULL)	{ kndev = STR_DF_KN_DEV; }
	if(rmdev == NULL)	{ rmdev = STR_DF_RM_DEV; }
	if(rfdev == NULL)	{ rfdev = STR_DF_RF_DEV; }

	return ERROR_OK;
}


/********************************************************************
 * Main function of this program.
********************************************************************/
int main( int argc, char* argv[] )
{
	// parse the cmd line input.
	if(ERROR_OK!=svr_parse_opt(argc, argv)){ return ERROR_OPT; }

	// set cleanup func.
	atexit(svr_cleanup);
	
	// init the socket to listen.
	if((sock_lsn = init_server()) < 0)
	{
		perror("init_server()");
		LOG_LINE;
		exit(errno);
	}
	
	// prompt a string.
	printf(_PROM_S "%s started!" _NL, argv[0]);
	printf(_PROM_S "kernel device = %s" _NL, kndev);
	printf(_PROM_S "ramfs  device = %s" _NL, rmdev);
	printf(_PROM_S "rootfs device = %s" _NL _NL, rfdev);

	int 	bShutdown 	= FALSE;
	while(!bShutdown)
	{
		// get the connectiong and do the welcomes.
		if((sock_cln = welcome(sock_lsn, svrversion)) < 0)
		{
			perror("welcome()");
			LOG_LINE;
			exit(errno);
		}

		// set timeout of recv() operation.
		struct timeval rcv_to; rcv_to.tv_sec=5; rcv_to.tv_usec=0;
		if( 0!=setsockopt(sock_cln, SOL_SOCKET, SO_RCVTIMEO, &rcv_to, sizeof(rcv_to)) ||
			0!=setsockopt(sock_cln, SOL_SOCKET, SO_SNDTIMEO, &rcv_to, sizeof(rcv_to)) )
		{
			perror("setsockopt()");
			LOG_LINE;
			exit(errno);
		}

		// start a loop to handle remote invoking.
		// each single loop handles one srpc_func.
		int bExit = FALSE;
		while(!bExit)
		{
			int 	rcv = 0, srpc_id = 0, paramsz = 0;
			byte* 	parambuf = NULL;

			// receive an int for srpc_id and an int for parameters' buffer size.
			if((rcv = recv_easy(sock_cln, &srpc_id, sizeof(int), MSG_WAITALL)) == -1){ LOG_LINE; exit(errno); }
			
			// if exit, quit this loop, so that server can accept other connection.
			if(rcv == 0 || srpc_id == _SRPC_ID_CLN_EXIT)
			{
				printf(_PROM_S "Client disconnected." _NL _NL);
				bExit = TRUE;
				break;
			}
			// if shutdown, quit this loop and the top loop, so that server shuts down.
			if(srpc_id == _SRPC_ID_SVR_SHUTDOWN)
			{
				printf(_PROM_S "Shutdown the server." _NL _NL);
				bShutdown = TRUE;
				break;
			}

			if((rcv = recv_easy(sock_cln, &paramsz, sizeof(int), MSG_WAITALL)) == -1){ LOG_LINE; exit(errno); }
			printf(_PROM_S "Received: srpc_id = %d, param size = %d" _NL, srpc_id, paramsz);

			// if param size != 0, there are params.
			if(paramsz!=0)
			{
				// malloc param buffer and receive the param data.
				parambuf = (byte*)malloc(paramsz);
				rcv = recv_easy(sock_cln, parambuf, paramsz, 0);
				if(rcv != paramsz)
				{
					if(parambuf!=NULL){free(parambuf); parambuf=NULL;}
					LOG_LINE;
					exit(errno);
				}
				printf(_PROM_S "Received: [%d] bytes param data." _NL, rcv);
			}

			// call the func. prepare the output variable first.
			byte* 		output  = NULL;
			int 		outsize = 0;
			// select a func, by srpc_id we received justnow.
			srpc_func 	rpcfunc	= service_list[srpc_id];
			// todo : check the scope of srpc_id.
			assert( srpc_id>=0 && srpc_id < _SRPC_ID_MAX );
			printf(_PROM_S "Calling remote service [%d] ..." _NL, srpc_id);
			
			// procedure the called func. This is the KEY point of srpc!
			int 		result  = rpcfunc(sock_cln, parambuf, rcv, &output, &outsize);
			// free the parameter's buffer.
			if(parambuf!=NULL){free(parambuf); parambuf=NULL;}

			// at least send the result and the output data size to the client.
			printf(_PROM_S "Sending remote calling result ... \n");
			if(	(send_easy(sock_cln, &result,  sizeof(int), 0) < sizeof(int)) ||
				(send_easy(sock_cln, &outsize, sizeof(int), 0) < sizeof(int)) )
			{
				if(output!=NULL){ free(output); output=NULL; }
				LOG_LINE;
				exit(errno);
			}
			// send the output data to client if there is some.
			if(outsize != 0 && output != NULL)
			{
				printf(_PROM_S "Sending output buffer ... \n");
				fflush(stdout);
				if(send_easy(sock_cln, output, outsize, 0) < outsize)
				{
					free(output); output=NULL;
					LOG_LINE;
					exit(errno);
				}
				free(output); output=NULL;
				printf("done.\n" _NL);
			}
			printf(_PROM_S "Remote service done." _NL _NL);
		}

		close(sock_cln); sock_cln = -1;
	}

	close(sock_lsn); sock_lsn = -1;

	return 0;
}


