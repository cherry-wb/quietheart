#include 	"suu_common.h"
#include 	"socket_util.h"

#include 	<errno.h>			/* for errno */
#include 	<stdio.h>			/* for printf(), fprintf(), sprintf() */
#include 	<stdlib.h>			/* for malloc(), realloc(), exit() */
#include 	<string.h>			/* for memset(), bzero() */
#include 	<assert.h>			/* for assert() */
#include 	<fcntl.h>			/* for fcntl() */
#include 	<linux/fs.h> 		/* for NR_OPEN, the max fd that linux allowed */
#include 	<netdb.h>			/* for gethostbyname() */
#include 	<arpa/inet.h>		/* for inet_ntoa(), htons() */
#include 	<sys/stat.h> 		/* for stat(), fstat(), lstat() */
#include 	<unistd.h> 			/* for close(), sleep(). */
#include 	<signal.h> 			/* for signal(). */

static char * const usage_str = 
			_TAB "-i <value> :  The server's ip or hostname. (default is \"localhost\" or \"127.0.0.1\")" _NL
			_TAB "-p <value> :  The server's port. (default is 3333)" _NL
			_TAB "-k <value> :  The kernel image path. (now inavailable)" _NL
			_TAB "-r <value> :  The ramfs image path." _NL
			_TAB "-f <value> :  The rootfs image path." _NL
			_TAB "-s <value> :  Shutdown the server." _NL
			_TAB "-h <value> :  Help" _NL;

static char* 	host 	= NULL;	/* server name or ip */
static int 		port 	= 0;	/* server port */
static char* 	knpath 	= NULL;
static char* 	rmpath 	= NULL;
static char* 	rfpath 	= NULL;
static int 		bshuts	= FALSE; /* whether shut the server down. */
static char* 	call 	= NULL;
static int 		sock_svr = -1;


void cln_cleanup(void)
{
	printf("\n" _PROM_C "cleaning up ... ");
	if(sock_svr > 0){ close(sock_svr); }
	printf("done.\n\n");
}


/********************************************************************
 * progress bar is shown as:
 * Progress: ########################################----------[ 80%]
 ********************************************************************/
int verbose_progress( unsigned int current, unsigned int total )
{
	static char 	progbar[60]; /* this is shown as a progress bar. */
	static int  	percent = -1; /* this is the progress percent. */
	int 			tokens 	= 0;
	unsigned int	newpcnt = 0;

	assert(current>=0);
	assert(total>0);
	assert(total>=current);

	/********************************************************************
	 avoid from overflow, because we would multiply a 100, 
	 and that multiplication might cause a overflow.
	 ********************************************************************/
	current = total >= 10000 ? current/100 : current;
	total 	= total >= 10000 ? total/100 : total; 
	newpcnt = current*100/total;

	/* if nothing is changed. */
	if(percent == newpcnt){	return (100==percent ? 1 : 0); }

	percent = newpcnt;
	tokens 	= (percent+1)/2;

	memset(&(progbar[0]), '-', 50);
	if(tokens>0){memset(&(progbar[0]), '#', tokens);}
	sprintf(&(progbar[50]), "[%3d%%]", percent);

	printf(_CR "Progress: %s", &(progbar[0]));
	fflush(stdout);

	/* if percent is 100, trun the variable state back to -1, and return 1.*/
	if(percent==100)
	{
		percent = -1;
		printf(_NL);		
		return 1;
	}
	
	return 0;
}


/********************************************************************
 * 1, Receive message from socket. 
 * 	  The messsage is like "e97%" for erase progress 97%.
 * 2, Show this progress on terminal screen.
 *
 * return 0 if OK, return -1 if error occurs while receiving data.
 ********************************************************************/
static int feedback_progress(int sock, char flag)
{
	int ret = 0;
	static char	message[NUM_PROGRESS_MSG_LEN];
	verbose_progress(0, 100);
	static int cnt = 0;
	int msglen = 6;
	while(1)
	{
		memset(message, 0, NUM_PROGRESS_MSG_LEN);
		int rcv = recv_easy(sock, message, msglen, 0);
		if( -1 == rcv || 0 == rcv ){ return -1; }
		/* the first char is flag. */
		if( *message != flag )
		{
			/* maybe this is because the network is not good, we give it 100 times. */
			cnt++;
			if(cnt == 100)
			{
				ret = -1;
				printf("\nError: recv progress percent from server. recv=[%s]"_NL, message);
				break;
			}
			continue;
		}
		else
		{
			if(verbose_progress(atoi(message+1), 100)){ break; }
		}
	}
	cnt = 0;
	return ret;
}


int update_flash(int sock_svr, char* image, int srpc_id)
{
	assert( image != NULL );
	
	/********************************************************************
	 image file should only be regular file, but not dir, link, fifo, dev, etc.
	********************************************************************/
	struct stat 	finfo;
	lstat(image, &finfo);
	int 	fsize 	= finfo.st_size;
	if(!S_ISREG(finfo.st_mode))
	{
		printf(_PROM_C "error : %s is not a regular file." _NL, image);
		return ERROR_FILE_IS_NOT_REG;
	}

	/********************************************************************
	 send input to server. here just call a remote func to run, so that we 
	 can interact with it.
	********************************************************************/
	if(0!=srpc_input(sock_svr, srpc_id, 0, NULL)){ exit(errno); }

	/********************************************************************
	 send the dest filename and buffer size.
	********************************************************************/
	int maxbuf = MAXBUFFER;
	if(send_easy(sock_svr, &fsize, sizeof(int), 0) < sizeof(int)) { exit(errno); }
	if(send_easy(sock_svr, &maxbuf, sizeof(int), 0) < sizeof(int)) { exit(errno); }

	/*===============================================> send the content start. */
	printf("Client :> Start to send kernel image to server." _NL);
	FILE* 	file 	= fopen(image, "r");
	byte* 	buf 	= (byte*)malloc(MAXBUFFER);
	int 	rdsz 	= 0;
	int 	count 	= 0;
	while(1)
	{
		rdsz = fread(buf, 1, MAXBUFFER, file);
		if(rdsz == 0){break;}
		if(send_easy(sock_svr, buf, rdsz, 0) < rdsz)
		{
			if(buf!=NULL){ free(buf); buf=NULL; }
			exit(errno);
		}
		count += rdsz;
		if(verbose_progress(count, fsize)){ break; };
	}
	fclose(file);
	if(buf!=NULL){free(buf); buf=NULL;}
	/*===============================================> send the content done. */

	/*===============================================> receive erase,write,verify progress percent. */
	int 	step;
	for(step=1; step<=3; step++)
	{
		char	flag;
		switch(step){
			case 1:
				flag = 'e';
				printf("Client :> Start to erase flash." _NL);
				break;
			case 2:
				flag = 'w';
				printf("Client :> Start to write flash." _NL);
				break;
			case 3:
				flag = 'v';
				printf("Client :> Start to verify flash." _NL);
				break;
			default: break;
		}
		if(0!=feedback_progress(sock_svr, flag)){ exit(errno); }
	}
	/*===============================================> receive erase,write,verify progress percent. */

	int ret = 0;
	if(0!=srpc_output(sock_svr, &ret, NULL, NULL)){ exit(errno); }
	return ret;
}


/********************************************************************
 * return the result of the remote procedure calling.
 ********************************************************************/
int srpc_update_kernel(int sock_svr, char* image)
{
	printf(_NL _PROM_C "Start to update kernel." _NL);
	int ret = update_flash(sock_svr, image, _SRPC_ID_UPDATE_KERNEL);
	printf(_PROM_C "Finish updating kernel." _NL);
	return ret;
}


/********************************************************************
 * return the result of the remote procedure calling.
 ********************************************************************/
int srpc_update_ramfs(int sock_svr, char* image)
{
	printf(_NL _PROM_C "Start to update ramfs." _NL);
	int ret = update_flash(sock_svr, image, _SRPC_ID_UPDATE_RAMFS);
	printf(_PROM_C "Finish updating ramfs." _NL);
	return ret;
}


/********************************************************************
 * return the result of the remote procedure calling.
 ********************************************************************/
int srpc_update_rootfs(int sock_svr, char* image)
{
	printf(_NL _PROM_C "srpc_update_rootfs begins." _NL);
	assert( image != NULL );

	/********************************************************************
	 image file should only be regular file, but not dir, link, fifo, dev, etc.
	********************************************************************/
	struct stat finfo;
	lstat(image, &finfo);
	int 	fsize 	= finfo.st_size;
	if(!S_ISREG(finfo.st_mode))
	{
		printf(_PROM_C "error : can not open file %s." _NL, image);
		return ERROR_FILE_IS_NOT_REG;
	}

	/********************************************************************
	 send input to server. here just call a remote func to run, so that we 
	 can interact with it.
	********************************************************************/
	if(0!=srpc_input(sock_svr, _SRPC_ID_UPDATE_ROOTFS, 0, NULL)){ exit(errno); }

	/********************************************************************
	 send the dest filename and buffer size.
	********************************************************************/
	int maxbuf = MAXBUFFER;
	if(send_easy(sock_svr, &fsize, sizeof(int), 0) < sizeof(int)){ exit(errno); }
	if(send_easy(sock_svr, &maxbuf, sizeof(int), 0) < sizeof(int)){ exit(errno); }

	/*===============================================> receive scan progress percent start. */
	int goodluck = 1;
	if(goodluck){ printf(_PROM_C "Start to scan flash." _NL); }
	if(0!=feedback_progress(sock_svr, 's'))
	{
		goodluck = 0;
	}
	/*===============================================> receive scan progress percent done. */

	/*===============================================> send the content start. */
	if(goodluck)
	{
		printf(_PROM_C "Start to program flash." _NL);
		FILE*	file	= fopen(image, "r");
		byte*	sbuf	= (byte*)malloc(MAXBUFFER);
		int 	rdsz	= 0;
		int 	count	= 0;
		while(1)
		{
			rdsz = fread(sbuf, 1, MAXBUFFER, file);
			if(rdsz < MAXBUFFER)
			{
				printf("rdsz = %d, bufsz = %d"_NL, rdsz, MAXBUFFER);
				if(rdsz==0){ break; }
			}
			if(send_easy(sock_svr, sbuf, rdsz, 0) < rdsz)
			{
				if(sbuf!=NULL){free(sbuf); sbuf=NULL;}
				goodluck = 0;
				break;
			}
			count += rdsz;
			if(verbose_progress(count, fsize)){ break; }
		}
		fclose(file);
		if(sbuf!=NULL){free(sbuf); sbuf=NULL;}
	}
	/*===============================================> send the content done. */

	/*===============================================> receive format progress percent start. */
	if(goodluck)
	{
		printf(_PROM_C "Start to format flash." _NL);
		if(0!=feedback_progress(sock_svr, 'f')){ goodluck = 0; }
	}
	/*===============================================> receive format progress percent done. */

	int ret = 0;
	if(0!=srpc_output(sock_svr, &ret, NULL, NULL)){ exit(errno); }
	if(ret != 0){ printf(_PROM_C "srpc_update_rootfs() returns %d\n", ret); }
	return ret;
}


/********************************************************************
 * return the result of the remote procedure calling.
 ********************************************************************/
int srpc_get_server_info(int sock_svr, char** output, int* size)
{
	int ret = 0;
	srpc_call(sock_svr, _SRPC_ID_GET_SVR_INFO, NULL, 0, (byte**)output, size, &ret);
	return ret;
}


/********************************************************************
 * return 0 if remote calling succeeded, -1 if error occurs.
 * this func just send a command, but does not care about the result.
 ********************************************************************/
int srpc_shutdown_server(int sock_svr)
{
	return srpc_input(sock_svr, _SRPC_ID_SVR_SHUTDOWN, 0, NULL);
}


/********************************************************************
 * Show usage of this routine onto the terminal.
 ********************************************************************/
static void usage( const char* appname )
{
	printf("Usage: %s [options]" _NL, appname);
	printf("%s", usage_str);
}


/********************************************************************
 * Parce the command line options of this program.
 ********************************************************************/
int cln_parse_opt(int argc, char * const argv[])
{
	if( argc < 2 )
	{
		usage(argv[0]);
		return ERROR_OPT;
	}
	
	int i;
	for(i=1; i< argc; i++)
	{
		if(argv[i][0] == '-')
		{
			if(2!=strlen(argv[i]))
			{
				usage(argv[0]);
				return ERROR_OPT;
			}
			switch(argv[i][1])
			{
				case 'i':
					host = argv[++i];
					break;
				case 'p':
					port = atoi(argv[++i]);
					if(port<1024 || port > 65535)
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
					
				case 'k':
					knpath = argv[++i];
					if(knpath == NULL || knpath[0] == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;

				case 'r':
					rmpath = &(argv[++i][0]);
					if(rmpath == NULL || *rmpath == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
					
				case 'f':
					rfpath = &(argv[++i][0]);
					if(rfpath == NULL || *rfpath == '-')
					{
						usage(argv[0]);
						return ERROR_OPT;
					}
					break;
					
				case 's':
					bshuts = TRUE;
					break;
					
				case 'c':
					call = argv[++i];
					break;
					
				case 'h':
				default:
					usage(argv[0]);
					return ERROR_OPT;
			}
		}
		else
		{
			usage(argv[0]);
			return ERROR_OPT;
		}
	}

	if(host == NULL){ host = "127.0.0.1"; }
	if(port == 0){ port = SERVPORT; }

	return ERROR_OK;
}


/********************************************************************
 * Signal handler.
 ********************************************************************/
void cln_sig_int(int sig)
{
	printf("\n\n"_PROM_C "SIGINT received! Shutdown now!\n");
	exit(1);
}


/********************************************************************
 * Main function of this program.
 ********************************************************************/
int main( int argc, char* argv[] )
{
	/* set cleanup */
	atexit(cln_cleanup);

	// set a signal handler.
	if(SIG_ERR == signal(SIGINT, cln_sig_int))
	{
		printf(_PROM_C "signal(SIGINT) error!\n");
		exit(1);
	}

	/* parse the cmd line input. */
	if(ERROR_OK!=cln_parse_opt(argc, argv)){ return ERROR_OPT; }

	/* print some info. */
	printf(_PROM_C "Client started!" _NL _NL);
	printf(_PROM_C"server_ip = %s" _NL
		"          port      = %d" _NL
		"          kernel    = %s" _NL
		"          ramfs     = %s" _NL
		"          rootfs    = %s" _NL, 
		host, port, knpath, rmpath, rfpath);

	/* init srpc. */
	char* str_svrver = NULL;
	sock_svr = srpc_init(host, port, 10, &str_svrver);
	if(str_svrver!=NULL)
	{
		printf(_PROM_C "Server Version - %s\n", str_svrver);
		free(str_svrver);
		str_svrver=NULL;
	}
	if(sock_svr<0){return ERROR_SOCKET;}

	/* set timeout of recv() operation. */
	struct timeval rcv_to; rcv_to.tv_sec=5; rcv_to.tv_usec=0;
	if(0!=setsockopt(sock_svr, SOL_SOCKET, SO_RCVTIMEO, &rcv_to, sizeof(rcv_to)))
	{
		perror("setsockopt()");
		exit(errno);
	}

	char* mtdinfo = NULL;
	int size;
	if( 0 == srpc_get_server_info(sock_svr, &mtdinfo, &size) )
	{
		assert(mtdinfo!=NULL);
		int parts = size > 0 ? 1 : 0;
		char* str = mtdinfo;
		// count how many '\n', notice the last line has not a '\n', and the first line is not a partition.
		for(; ((str = strchr(str, '\n')) != NULL) && (*str != '0'); parts++, str++);
		printf(_PROM_C "mtd partitions info: (%d partitions)\n", --parts);
		printf("%s\n", mtdinfo);
	}
	if(mtdinfo!=NULL){ free(mtdinfo); mtdinfo=NULL; }

	/* deal with kernel image. */
	if(knpath != NULL)
	{
		/* copy file to server. */
		if(srpc_update_kernel(sock_svr, knpath) < 0)
		{
			printf(_PROM_C "error : copy file[%s] to server as %s but failed.\n", knpath, STR_KERNEL);
		}
		else
		{
			printf(_PROM_C "copy file[%s] to server as %s, done.\n", knpath, STR_KERNEL);
		}
	}

	/* deal with ramfs image. */
	if(rmpath != NULL)
	{
		/* copy file to server. */
		if(srpc_update_ramfs(sock_svr, rmpath) < 0)
		{
			printf(_PROM_C "error : copy file[%s] to server as %s but failed.\n", rmpath, STR_RAMFS);
		}
		else
		{
			printf(_PROM_C "copy file[%s] to server as %s, done.\n", rmpath, STR_RAMFS);
		}
	}

	/* deal with rootfs image. */
	if(rfpath != NULL)
	{
		/* copy file to server. */
		int ret = srpc_update_rootfs(sock_svr, rfpath);
		if(ret < 0)
		{
			printf(_PROM_C "error : copy file[%s] to server as %s but failed. srpc return [%d]\n", rfpath, STR_ROOTFS, ret);
		}
		else
		{
			printf(_PROM_C "copy file[%s] to server as %s, done.\n", rfpath, STR_ROOTFS);
		}
	}

	/* shutdown the server. */
	if(TRUE == bshuts)
	{
		printf(_NL _PROM_C "Shutdown the server ... ");
		fflush(stdout);
		srpc_shutdown_server(sock_svr);
		printf("Done.\n");
	}

	/* close the socket. */
	srpc_exit(sock_svr);

	return ERROR_OK;
}

