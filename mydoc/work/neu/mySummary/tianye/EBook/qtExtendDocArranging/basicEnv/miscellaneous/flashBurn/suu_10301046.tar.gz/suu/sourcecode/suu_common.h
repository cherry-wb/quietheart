#ifndef 	_SUU_COMMON_H_
#define 	_SUU_COMMON_H_

/* ============================ Preprocessor macro definitions start ==*/
#define 	TRUE 				(1)
#define 	FALSE 				(0)

#define 	ERROR_OK 					0
#define 	ERROR_OPT 					-1
#define 	ERROR_SOCKET				-2
#define 	ERROR_FILE_IS_NOT_REG		-3

#define 	NUM_PROGRESS_MSG_LEN 		(10)

#define 	SERVHOST 			("127.0.0.1");
#define 	SERVPORT 			(3333)	/* server port */
#define 	MAXACCESS 			(10)	/* max concurrent access request to server */
#define 	MAXBUFFER			(4096) 	/* max buffer */
#define 	MEMBLOCKSIZE		(4096)	/* mem block size */

#define 	LOG_LINE 			{printf("%s:  %d\n", __FILE__, __LINE__);}

#define 	STR_KERNEL 			("kernel")
#define 	STR_RAMFS 			("ramfs")
#define 	STR_ROOTFS 			("rootfs")

#define 	_TAB 				"\t"
#define 	_CR 				"\r"
#define 	_NL					"\n"
#define 	_PROM_C 			"Client :> "
#define 	_PROM_S 			"Server :> "

/* ============================ Preprocessor macro definitions end ====*/

/* ============================ typedef start =========================*/

#ifndef 	_TYPE_BYTE_
#define 	_TYPE_BYTE_
typedef unsigned char			byte;
#endif // _TYPE_BYTE_

typedef struct _memblock
{
	byte*	base;		// base mem addr.
	int		size;		// buffer size that is used.
	int		offset;		// offset to copy.
	int		szblock;	// real size of the mem block.
} memblock;

typedef enum _SRPC_ID
{
	_SRPC_ID_CLN_EXIT = 0,
	_SRPC_ID_SVR_SHUTDOWN,
	_SRPC_ID_GET_SVR_INFO,
	_SRPC_ID_UPDATE_KERNEL,
	_SRPC_ID_UPDATE_RAMFS,
	_SRPC_ID_UPDATE_ROOTFS,
	_SRPC_ID_MAX,
} SRPC_ID;

/* ============================ typedef end ===========================*/


/* ============================ function declarations start ===========*/

byte* bytecopy( memblock* mem, const void * src, int size);

/* ============================ function declarations end =============*/

#endif // _SUU_COMMON_H_

