#!/bin/sh

#====================================================
# const variables.
#====================================================
CONFIG=ubifs_tmp.cfg
TMP_IMG=ubifs_tmp.img

# mkfs.ubifs and ubinize are typically in /sbin/
APP_mkfs_ubifs=mkfs.ubifs
APP_ubinize=ubinize

#====================================================
# very important variables for ubi-utils.
# min_io_sz   : smallest io size.
# logic_e_sz  : logical erase block size.
# logic_e_cnt : how many logical erase block the 
#               image can reach.
# physi_e_sz  : physical erase block size.
# sub_page_sz : default sub page is min_io_sz, so we
#               just use min_io_sz.
#====================================================
min_io_sz=2KiB
logic_e_sz=258048
logic_e_cnt=3000
physi_e_sz=256KiB

#====================================================
# show usage if necessary.
#====================================================
if [ $# -gt 4 ] || [ $# -lt 2 ]; then 
	echo "Usage: mkubifs.sh <output image name> <rootfs dir> [volume size] [volume name]"
	echo "       'image size' is like '800MiB'. (use KiB, MiB)"
	exit 1;
fi

#====================================================
# init some variables.
# Note: 
#  VOL_SIZE must less than (logic_e_sz * logic_e_cnt)
#====================================================
OUTPUT_IMG=$1
ROOTFS_DIR=$2
VOL_SIZE=$3
VOL_NAME=$4

if [ -z ${VOL_SIZE} ] ; then VOL_SIZE=800MiB; fi
if [ -z ${VOL_NAME} ] ; then VOL_NAME=rootfs; fi

#====================================================
# make a cfg file.
#====================================================
rm -rf ${CONFIG}
echo "[rootfs]"              >> ${CONFIG}
echo "mode=ubi"              >> ${CONFIG}
echo "image=${TMP_IMG}"      >> ${CONFIG}
echo "vol_id=0"              >> ${CONFIG}
echo "vol_size=${VOL_SIZE}"  >> ${CONFIG}
echo "vol_type=dynamic"      >> ${CONFIG}
echo "vol_name=${VOL_NAME}"  >> ${CONFIG}
echo "vol_flags=autoresize"  >> ${CONFIG}
echo ">> create config file ${CONFIG}"

#====================================================
# make temporary ubifs image, then config the image.
# the arguments of the 'mkfs.ubifs' and 'ubinize'
# should be different for nand and nor flash. so the 
# arguments must be configured first, manually.
#====================================================
echo ">> ${APP_mkfs_ubifs} -m ${min_io_sz} -e ${logic_e_sz} -x lzo -c ${logic_e_cnt} -d ${ROOTFS_DIR} -o ${TMP_IMG}"
${APP_mkfs_ubifs} -m ${min_io_sz} -e ${logic_e_sz} -x lzo -c ${logic_e_cnt} -d ${ROOTFS_DIR} -o ${TMP_IMG}
echo ">> ${APP_ubinize} -o ${OUTPUT_IMG} -m ${min_io_sz} -p ${physi_e_sz} -s ${min_io_sz} ${CONFIG}"
${APP_ubinize} -o ${OUTPUT_IMG} -m ${min_io_sz} -p ${physi_e_sz} -s ${min_io_sz} ${CONFIG}

#====================================================
# clean the temporary files.
#====================================================
echo ">> clean temporary files ${CONFIG} ${TMP_IMG}"
rm -f ${CONFIG}
rm -f ${TMP_IMG}
