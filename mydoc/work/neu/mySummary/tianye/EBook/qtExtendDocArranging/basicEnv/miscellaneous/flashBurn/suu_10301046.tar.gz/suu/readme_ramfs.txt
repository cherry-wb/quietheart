﻿ramfs是一种基于内存的文件系统。它将一段内存虚拟成块设备，内核像操作真正文件系统一样操作其上的设备，但下电后其中的数据将被全部放弃。
我们采用ramfs作为suu的载体，因为ramfs体积非常小。

ramfs镜像的制作：
1，准备一个文件系统，不妨令其路径为/usr/local/ramdisk
   注：suu/suu_host/utils/utils-ramfs/路径下有一个ramdisk.tar.gz，将其解压后即为一个可做成ramfs镜像的文件系统。本文读者可以在这个文件系统上稍作修改。
2，在PC上解压suu_host.tar.gz
3，进入suu_host/utils/utils-ramfs/路径下
4，将mkimage应用程序拷贝至任何$PATH包含的路径下，例如/usr/bin/下（推荐）
   如果不允许污染当前PC端环境，则修改mkramfs.sh中的对应的变量，参见mkramfs.sh脚本
5，运行命令：
#  ./mkramfs.sh <image name> <filesys dir>
例如 ./mkramfs.sh ramfs.img /usr/local/ramdisk
说明：
image name : 输出的ramfs镜像的文件名。
filesys dir : 将被制成ramfs镜像的文件系统的路径。

如需要获得更多信息，请参考 mkramfs.sh 文件中的内容。
