#include 	<stdlib.h>		// for realloc()
#include 	<string.h>		// for memcpy()

#include 	"suu_common.h"

// if memory is not enough, realloc some.
// this func is used to make a big buffer for several params,
// and send them to server by just one send() func.
byte* bytecopy( memblock* mem, const void * src, int size)
{
	if((mem->offset + size) > mem->szblock)
	{
		mem->szblock += MEMBLOCKSIZE;
		mem->base = (byte*)realloc(mem->base, mem->szblock);
		return bytecopy( mem, src, size);
	}
	else
	{
		memcpy((mem->base + mem->offset), src, size);
		mem->offset += size;
		mem->size = mem->offset > mem->size ? mem->offset : mem->size;
		return (mem->base + mem->offset);
	}
}

