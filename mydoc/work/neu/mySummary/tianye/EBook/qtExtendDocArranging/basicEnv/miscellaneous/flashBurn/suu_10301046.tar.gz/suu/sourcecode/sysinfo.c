#include <arpa/inet.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

#include "sysinfo.h"

#define Log_line printf("%s: %d\n", __FILE__, __LINE__)

// return a string buffer containing the info of mtd devices.
// return the count of mtd devices stored in *cnt.
// params mtdinfo and cnt may both be NULL, if you dont care.
// that is how many /dev/mtdn which the system has.
// the buffer is allocated by function, to ensure the info is entire,
// so the buffer needs to be freed manually by the user.
char* sysinfo_getmtd(char** mtdinfo, int * cnt)
{
	static int block = 1024;
	int		bRedo	= 0;
	int		size	= block;
	int		count	= 0;
	int		len		= 0;
	char*	mtd		= (char*)calloc(size, sizeof(char));
	char*	buf		= mtd;
	FILE*	pfile	= fopen("/proc/mtd", "r");
	if(NULL==pfile)
	{
		printf("Cannot open /proc/mtd\n");
		return NULL;
	}
	while(fgets(buf, size, pfile)!=NULL)
	{
		//if(0!=strncmp(buf, "mtd", strlen("mtd"))){ continue; }
		len    = strlen(buf);
		size  -= len;
		buf   += len;
		count ++;
		if(size<2) // need 2 bytes for a '\n' and a '\0'.
		{
			bRedo = 1;
			break;
		}
	}
	fclose(pfile);
	if(bRedo)
	{
		// it seems that we need a larger buffer.
		// we drop all work that has been done here,
		// free all mem allocated in this func.
		// make the buffer size larger and do the job again.
		free(mtd);
		block *= 2;
		return sysinfo_getmtd(mtdinfo, cnt);
	}
	if(buf-1>=mtd && *(buf-1)=='\n')
	{
		// remove the last '\n' char.
		*(buf-1) = '\0';
	}
	if(mtdinfo!=NULL){ *mtdinfo = mtd; }
	if(cnt!=NULL){ *cnt = count; }
	return mtd;
}

// return a string of linux version.
// the return buffer is allocated by user.
char* sysinfo_getversion(char* vers, int size)
{
	assert(vers!=NULL && size>1);
	FILE* pfile = fopen("/proc/version", "r");
	if(NULL==pfile)
	{
		printf("Cannot open /proc/version\n");
		return NULL;
	}
	int rd = fread(vers, sizeof(char), size-1, pfile);
	fclose(pfile);
	// remove the last '\n'
	if(rd>0 && *(vers+rd-1)=='\n'){ *(vers+rd-1) = '\0'; }
	return vers;
}

// return total mem and free mem (KiB).
// return -1 means open error.
long int sysinfo_getmeminfo(long int* totalm, long int* freem)
{
	long int ttm, frm;
	int exitflag = 0;
	// this buf should be more than 27 chars.
	// 'cause /proc/meminfo has 27 chars per line (count the '\0').
	char buf[30];
	
	FILE* pfile = fopen("/proc/meminfo", "r");
	if(NULL==pfile)
	{
		printf("Cannot open /proc/meminfo\n");
		return -1;
	}
	while(exitflag != 2)
	{
		// get a line from the file.
		fgets(buf, 30, pfile);
		if(!strncmp(buf, "MemTotal", strlen("MemTotal")))
		{
			// +1 to moveover the ':' char.
			ttm = atol(&(buf[strlen("MemTotal")+1]));
			assert(ttm!=0);
			exitflag++;
		}
		else if(!strncmp(buf, "MemFree", strlen("MemFree")))
		{
			// +1 to moveover the ':' char.
			frm = atol(&(buf[strlen("MemFree")+1]));
			assert(ttm!=0);
			exitflag++;
		}
	}
	if(totalm!=NULL){ *totalm = ttm; }
	if(freem!=NULL){ *freem = frm; }
	fclose(pfile);
	return frm;
}

// return a string of hostname.
// return NULL means open error.
// the return buffer is allocated by the user.
char* sysinfo_gethostname(char* hname, int size)
{
	assert(hname!=NULL && size>1);
	FILE* pfile = fopen("/proc/sys/kernel/hostname", "r");
	if(NULL==pfile)
	{
		printf("Cannot open /proc/sys/kernel/hostname\n");
		return NULL;
	}
	fgets(hname, size, pfile);
	fclose(pfile);
	// remove the last '\n'
	int len;
	if((len = strlen(hname))>0){ *(hname+len-1)='\0'; }
	return hname;
}

int test(void)
{
	// test reading info from /proc/*
	// 1. hostname. in /proc/sys/kernel/hostname
	char name[256];
	char* pname = sysinfo_gethostname(name, 256);
	// hostname has a '\n' at last.
	printf("Hostname: %s\n", pname);

	// 2. meminfo. in /proc/meminfo
	long int totalmem, freemem;
	sysinfo_getmeminfo(&totalmem, &freemem);
	printf("MemInfo: total=[%ld KiB], free=[%ld KiB]\n", totalmem, freemem);

	// 3. cpuinfo. in /proc/cpuinfo
	char version[256];
	sysinfo_getversion(version, 256);
	// version string has a '\n' at last.
	printf("%s\n", version);
	fflush(stdout);

	//*
	// 4. mtd. in /proc/mtd
	char* mtdinfo = NULL;
	int mtdcnt = 0;
	sysinfo_getmtd(&mtdinfo, &mtdcnt);
	printf("%d mtd device/partition(s):\n%s\n", mtdcnt, mtdinfo);
	if(NULL!=mtdinfo){ free(mtdinfo); mtdinfo=NULL; }
	//*/

	return 0;
}
