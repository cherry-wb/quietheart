#!/bin/sh

# 1, select the spi-flash
echo flash > /sys/devices/platform/mv-spi/spi_cs

# 2, insert spi-flash driver module
insmod sflash.ko

# 3, insert partition module
insmod flashmap.ko

# 4, see the result
cat /proc/mtd
