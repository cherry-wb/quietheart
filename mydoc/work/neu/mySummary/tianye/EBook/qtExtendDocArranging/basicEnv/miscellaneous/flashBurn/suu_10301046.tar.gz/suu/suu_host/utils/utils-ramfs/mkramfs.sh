#!/bin/sh

if [ $# != 2 ] ; then 
	echo "Usage: mkramfs.sh <image name> <filesys dir>"
	echo "       E.G. mkramfs.sh initrd.img ./ramdisk"
	exit 1
fi

# make sure there is a good mkimage.
# this routine typically goes with a u-boot.
MKIMAGE=mkimage

# memaddr must be the same as what you set in your bootloader!
memaddr=0x8f2e0000

image_file=$1
fs_dir=$2

orig_dir=`pwd`
tmpfile=tmpfile

cd ${fs_dir}
find . | cpio -o -H newc > ${orig_dir}/${tmpfile}
cd ${orig_dir}
gzip ${tmpfile}
${MKIMAGE} -A arm -O linux -T ramdisk -C none -a ${memaddr} -n ramdisk -d ${tmpfile}.gz ${image_file}
rm ${tmpfile}.gz
