/* ============================ include headers start =================*/
//#include <sys/types.h>
//#include <sys/socket.h>
//#include <sys/wait.h>
//#include <netinet/in.h>
//#include <sys/select.h>	/* for select() */
/* headers above are autometically included by gcc */

#include 	<errno.h>			/* for errno */
#include 	<stdio.h>			/* for printf() */
#include 	<stdlib.h>			/* for malloc(), realloc(), exit() */
#include 	<string.h>			/* for bzero() */
#include 	<arpa/inet.h>		/* for inet_ntoa(), htons() */
#include 	<unistd.h>			/* for fork(), close(), open(), read() */
#include 	<assert.h>			/* for assert() */
#include 	<netdb.h>			/* for gethostbyname() */
#include 	<fcntl.h>			/* for fcntl() */
#include 	<linux/fs.h> 		/* for INR_OPEN, the max fd that linux allowed */

#include 	"socket_util.h"
/* ============================ include headers end ===================*/



/****************************************************************
 *	Description:
 *		Describe the errno using the default message.
 *
 ****************************************************************/
void printerr(const char* prompt)
{
	fprintf(stdout, "\n%s: [%d] %s\n", prompt, errno, strerror(errno));
}

/****************************************************************
 *	Description:
 *		Describe the errno using the given message.
 *
 ****************************************************************/
void printerrmsg(const char* prompt, const char* msg)
{
	fprintf(stdout, "\n%s: [%d] %s\n", prompt, errno, msg);
}

/****************************************************************
 *	Description:
 *		recv() func with exception handling.
 *
 ****************************************************************/
int recv_easy(int socket, void * buffer, int length, int flags)
{
	flags |= MSG_NOSIGNAL;
	errno = 0;
	int ret = recv(socket, buffer, length, flags);
	if(ret != -1){return ret;}
	static const char* prompt = "\nSocket Error";
	switch(errno)
	{
		case EAGAIN:
			printerrmsg(prompt, "Blocking timed out while receiving data. Please check the connection.");
			break;
		case EBADF:
		case EFAULT:
		case EINTR:
		case EINVAL:
		case ENOBUFS:
		case ENOMEM:
		case ETIMEDOUT:
		case ECONNRESET:
		case ENOTCONN:
		case ENOTSOCK:
		case EOPNOTSUPP:
		default:
			printerr(prompt);
			break;
	}
	return ret;
}


/****************************************************************
 *	Description:
 *		send() func with exception handling.
 *
 ****************************************************************/
int send_easy(int socket, const void * buffer, int length, int flags)
{
	flags |= MSG_NOSIGNAL;
	errno = 0;
	int ret = send(socket, buffer, length, flags);
	if(ret == length){return ret;}
	static const char* prompt = "\nSocket Error";
	switch(errno)
	{
		case EINPROGRESS:
			/* ret is not -1 but less than length. */
			printerrmsg(prompt, "Connection error while sending data.");
			break;
		case EACCES:
		case EAGAIN:
		case EBADF:
		case ECONNRESET:
		case EFAULT:
		case EHOSTUNREACH:
		case EINTR:
		case EMSGSIZE:
		case ENETDOWN:
		case ENETUNREACH:
		case ENOBUFS:
		case ENOTSOCK:
		case EOPNOTSUPP:
		case EPIPE:
		case EDESTADDRREQ:
		case ENOTCONN:
		default:
			printerr(prompt);
			break;
	}
	return ret;
}


/****************************************************************
 *	Description:
 *		Build a socket connecting to the server.
 *
 *	Input:
 *		ipaddress	:	string. 
 *						A dotted decimal string, E.g.: 10.1.14.38
 *		port		:	int.
 *						Port being listened by the server.
 *		timeout		:	int.
 *						Wait how many seconds. 
 *						In linux kernel, the default value is 75.
 *
 *	Output:
 *		return the socket connecting to the server.
 *		OR return Errors.
 *
 *	Error:
 *		SPRC_ERROR_GETHOST, SPRC_ERROR_SOCKET, SPRC_ERROR_CONNECT
 ****************************************************************/
int connect_server( char* ipaddress, int port, int timeout )
{
	int						sock_fd;
	struct sockaddr_in		svr_addr;
	int						flags;
	fd_set					write_set;
	fd_set					read_set;
	struct timeval			tval;
	int						error;
	socklen_t				errlen;

	/* create a socket */
	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0))==-1)
		return SRPC_ERROR_SOCKET;

	/* init a parameter for connect() */
	svr_addr.sin_family		= AF_INET;
	svr_addr.sin_port		= htons(port);
	if(1!=inet_pton(AF_INET, ipaddress, &(svr_addr.sin_addr))){ return SRPC_ERROR_ADDRESS; }
	bzero(&(svr_addr.sin_zero), 8);

	/* set the socket as NON-BLOCK */
	flags = fcntl(sock_fd, F_GETFL, 0);
	fcntl(sock_fd, F_SETFL, flags | O_NONBLOCK);

	/* connect to server.
	 * it usually returns -1 and sets errno=EINPROGRESS */
	errno = 0; /* clear errno first */
	if(connect(sock_fd, (struct sockaddr *)&svr_addr, sizeof(struct sockaddr)) == 0)
	{
		//printf("connect return OK immeidately.\n");
		return sock_fd;
	}

	if(errno != EINPROGRESS)
	{
		close(sock_fd);
		return SRPC_ERROR_CONNECT_EXPECT_EINPROGRESS;
	}

	/* prepare arguments for select() */
	FD_ZERO(&read_set);
	FD_SET(sock_fd, &read_set);
	FD_ZERO(&write_set);
	FD_SET(sock_fd, &write_set);

	tval.tv_sec	 = timeout;
	tval.tv_usec = 0;

	/* test if sock_fd is ready for reading and writing within tval time.
	 * if sock_id is ready for both, returns 2.
	 * if sock_id is ready for one side, returns 1. 
	 * if sock_id is ready for none, but time is out, returns 0. 
	 * returns -1 means there is an error. 
	 * return value is at least 1 means socket would be done. */
	if(select(sock_fd+1, NULL, &write_set, NULL, &tval)<1)
	{
		close(sock_fd);
		return SRPC_ERROR_CONNECT_TIMEOUT;
	}

	error = 0;
	errlen = sizeof(error);
	if(getsockopt(sock_fd, SOL_SOCKET, SO_ERROR, &error, &errlen)<0 || error!=0)
	{
		close(sock_fd);
		return SRPC_ERROR_CONNECT_HAS_ERROR;
	}

	if(select(sock_fd+1, &read_set, NULL, NULL, &tval)<1)
	{
		close(sock_fd);
		return SRPC_ERROR_CONNECT_TIMEOUT;
	}

	error = 0;
	errlen = sizeof(error);
	if(getsockopt(sock_fd, SOL_SOCKET, SO_ERROR, &error, &errlen)<0 || error!=0)
	{
		close(sock_fd);
		return SRPC_ERROR_CONNECT_HAS_ERROR;
	}

	/* set sock_fd back to BLOCK */
	fcntl(sock_fd, F_SETFL, flags);
	
	/* now sock_fd is ready to read and write */
	return sock_fd;
}


/****************************************************************
 *	Description:
 *		First communication with server. 
 * 		that is, get a server version string from server.
 *
 ****************************************************************/
int greeting(int sock_svr, char** verstr)
{
	int 	rcv 		= 200;
	int 	versize 	= 0;
	// get server version size.
	if((rcv = recv_easy(sock_svr, &versize, sizeof(int), MSG_WAITALL)) == -1) assert(0);
	// size should not be 0.
	assert(rcv != 0);
	// get server version and show it.
	char* 	verbuf 	= (char*)malloc(versize);
	rcv = recv_easy(sock_svr, verbuf, versize, 0);
	if(rcv == -1 || rcv != versize) assert(0);
	//printf("Server info [%d bytes]: %s\n", rcv, verbuf);
	if(verstr!=NULL)
	{
		// need to free the buffer outside this func, manually.
		*verstr = verbuf;
	}
	else
	{
		// free the buffer immediately.
		if(verbuf!=NULL){free(verbuf); verbuf=NULL;};
	}
	return versize;
}


/****************************************************************
 *	Description:
 *		Init the socket connection for srpc.
 *
 *	Input:
 *		hostname	:	string. 
 *						A dotted decimal string, E.g.: 10.1.14.38
 *		port		:	int.
 *						Port being listened by the server.
 *		timeout		:	int.
 *						Wait how many seconds. 
 *						In linux kernel, the default value is 75.
 *
 *	Output:
 *		if succeeded, return value is Zero, 
 * 		and static sock_svr is set within [0, INR_OPEN];
 *		otherwise, return value is less than Zero.
 *
 ****************************************************************/
int srpc_init( char* ipaddress, int port, int timeout, char** svrver )
{
	int sock_svr = connect_server( ipaddress, port, timeout );

	switch( sock_svr )
	{
		case SRPC_ERROR_ADDRESS:
			printf("\nError: bad ip address.\n");
			break;
		case SRPC_ERROR_SOCKET:
			printf("\nError: creating socket.\n");
			break;
		case SRPC_ERROR_CONNECT:
			printf("\nError: connecting.\n");
			break;
		case SRPC_ERROR_CONNECT_EXPECT_EINPROGRESS:
			printf("\nError: connecting expect in-progress.\n");
			break;
		case SRPC_ERROR_CONNECT_TIMEOUT:
			printf("\nError: connecting timeout.\n");
			break;
		case SRPC_ERROR_CONNECT_HAS_ERROR:
			printf("\nError: connecting encounters error! make sure the server is running, the ip and port is correct.\n");
			break;
		default:
			if(sock_svr<0)
			{
				printf("\nUnknown Socket Error!\n");
			}
			else if (sock_svr > INR_OPEN)
			{
				sock_svr = SRPC_ERROR_SOCKET_FD_ERROR;
			}
			break;
	}
	
	if(sock_svr>=0 && sock_svr <= INR_OPEN)
	{
		// normal situation, the socket is good.
		char* version = NULL;
		greeting(sock_svr, &version);
		if(svrver!=NULL){*svrver = version;}
		else if(version!=NULL){free(version); version=NULL;}
	}

	return sock_svr;
}


/****************************************************************
 *	Description:
 *		Close the socket connection for srpc.
 *
 ****************************************************************/
void srpc_exit(int sock_svr)
{
	close(sock_svr);
}


/****************************************************************
 *	Description:
 *		Send input data to server.
 *
 *	Input:
 *		sock		:	int
 *		srpc_id		:	int
 *		input		:	byte*
 *		insize		:	int
 *
 *	Output:
 *		return 0.
 *
 ****************************************************************/
int srpc_input(int sock, int srpc_id, int input_size, byte* input_buf)
{
	input_size = input_buf ? input_size : 0;
	// send srpc_id.
	if(send_easy(sock, &srpc_id, sizeof(int), 0) < sizeof(int)){ return -1; };
	// send param buffer size.
	if(send_easy(sock, &input_size, sizeof(int), 0) < sizeof(int)){ return -1; };
	// send param buffer data if there is.
	if(input_buf!=NULL && input_size!=0)
	{
		if(send_easy(sock, input_buf, input_size, 0) < input_size){ return -1; };
	}

	return 0;
}


/****************************************************************
 *	Description:
 *		receive output data from server.
 *
 *	Input:
 *		sock		:	int
 *		result		:	int
 *		output		:	byte**
 *		outsize		:	int*
 *
 *	Output:
 *		return 0 if remote calling succeeded.
 *
 ****************************************************************/
int srpc_output(int sock, int* result, int* output_size, byte** output_buf)
{
	int 	rst 	= 0;
	
	int 	rcv 	= 0;
	int 	osize 	= 0;
	byte* 	tmpbuf 	= NULL;
	// recv result.
	if((rcv = recv_easy(sock, &rst, sizeof(int), MSG_WAITALL)) == -1){ return -1; }
	// recv output data size.
	if((rcv = recv_easy(sock, &osize, sizeof(int), MSG_WAITALL)) == -1){ return -1; }
	// recv output data.
	if(result != NULL){ *result = rst; }
	if(osize != 0)
	{
		tmpbuf = (byte*)malloc(osize);
		if((rcv = recv_easy(sock, tmpbuf, osize, 0)) == -1 || rcv != osize)
		{
			if(tmpbuf!=NULL){ free(tmpbuf); tmpbuf=NULL; }
			return -1;
		}
	}

	// if output_size or output_buf is NULL, it means the caller doesnt 
	// care the return value, so we just free the temp buffer.
	
	// set output_size value.
	if(output_size != NULL){*output_size = osize;}

	// set output_buf value.
	if(output_buf != NULL)
	{
		// It needs to be freed outside this func manually, if tmpbuf is not NULL.
		*output_buf = tmpbuf;
	}
	else
	{
		// free the temp buffer immediately.
		if(tmpbuf!=NULL){free(tmpbuf); tmpbuf=NULL;}
	}

	return 0;
}

/****************************************************************
 *	Description:
 *		Remote call server functions.
 * 		if *output is set, it must be freed outside this func manually.
 *		At least 8 byte data is sent to the server : 
 *		the srpc_id and the param_size.
 *
 *	Input:
 *		sock_svr 	: 	int
 *		srpc_id		:	int
 *		input		:	byte*
 *		insize		:	int
 *		output		:	byte**
 *		outsize		:	int*
 *		result 		: 	int*
 *
 *	Output:
 *		return 0 if remote calling succeeded, -1 if error occurs.
 *
 ****************************************************************/
int srpc_call(int sock_svr, int srpc_id, byte* input, int insize, byte** output, int* outsize, int* result)
{
	// send input data to server.
	if(-1 == srpc_input(sock_svr, srpc_id, insize, input)){ return -1; };

	// do nothing here.

	// recv output data from server.
	int 	ret = 0;
	if(-1 == srpc_output(sock_svr, &ret, outsize, output)){ return -1; };
	
	// return result.
	if(result!=NULL){ *result = ret; }

	return 0;
}


