﻿Standalone Update Utility（以下简称suu）使用说明
for Marvell kw 开发板（不带mini usb接口的）

Author: zhaohp@neusoft.com

本文配属附件：
suu_device/ —— 在ARM设备上使用的工具等。
suu_host/ —— 在作为host的X86 PC平台上使用的工具等。
在suu_host路径下带有kernel.img, ramfs.img和pegatron.img，分别是可用的内核、ramfs和rootfs的镜像文件。

其他参考文档：
《tftp.txt》——tftp服务器配置说明。tftp可能在第一次向flash烧写ramfs镜像时使用。
《readme_ubifs.txt》——ubifs image制作说明。ubifs是我们正常的rootfs采用的文件系统。
《readme_ramfs.txt》——ramfs image制作说明。ramfs是一种基于内存的文件系统，下电后所有内容将被放弃。

期待的文档：
《nfs.txt》——nfs服务器配置说明和nfs rootfs的制作。nfs可能在第一次向flash烧写ramfs镜像时使用。


============================== 正文开始 ===================================
suu的功能：
1，更新内核
2，更新ramfs
3，更新rootfs

suu的工作原理：
Ramfs是一种基于内存的文件系统，使用它作为根文件系统启动，不需要绑定任何flash，因此当kernel以一个ramfs作为rootfs启动后，即可对flash解锁和擦写。（类似，当kernel以nfs作为rootfs方式启动时，也能达到这个效果）
Suu工作在一个最小化的ramfs上。当ramfs作为根文件系统启动后，suu的device端即被运行，它绑定一个socket，并阻塞，监听来自任何ip地址的socket连接请求。此时用户在PC上运行suu的host端程序，该程序向device发起请求，要求更新kernel，ramfs或者rootfs等，然后向device端传递数据，动作结束后device端将执行结果返回PC host端。因此，从socket编程的角度，sed端的suu程序为server，PC host上的suu程序为client。

suu的工作前提：
1，kernel支持mtd驱动框架。
2，kernel支持ubifs文件系统。
3，kernel支持网络设备（ether网卡或RNDIS等）。
4，有效的flash驱动被编入内核，或能够在内核启动后加载。

suu目前的缺欠：
1，尚不支持向nand flash烧写kernel和ramfs。
1，错误处理不完善。当网络连接中断或者一方应用程序中断后，suu的错误处理可能会有bug，如内存泄露等。
2，suu还没有实现智能分析device信息，比如当用户要烧写的内核大于kernel分区总容量时，自动拒绝Update请求。
3，mtd分区必须固定，否则需要手动重启userver，才能启用新的参数
4，spi flash的驱动加载后，u-boot分区可见，也可以被修改。





使用suu的准备工作：
1，首次向开发板烧写ramfs
2，向u-boot添加一些环境变量，使其更易使用


===========================================================================
一、最简操作手顺（推荐）
---------------------------------------------------------------------------
这一部分几乎没有任何说明，只记录最简单的操作手顺。
该手顺将kernel.img和ramfs.img烧写到Marvell kw开发板的spi-flash上，并使u-boot引导内核启动时以ramfs作为根文件系统。

【重要】如果各位的PC端无法配置tftp，可以省略第1、2步，并在第4步中将serverip设置为10.1.14.37，这台机器上已经配置好tftp服务器，并已将kernel.img和ramfs.img放在tftp的共享目录下

1.  配置PChost端的tftp服务器，参见《tftp.txt》

2.  将suu.tar.gz解压，拷贝suu/suu_host/下的kernel.img和ramfs.img文件至tftp服务器共享目录下

3.  给开发板上电，确认网线已经连接，从PC端的minicom或hyper terminal进入u-boot

4.  在u-boot中进行如下操作：
（注：其中带中括号的内容，如[device ip]等，需要视情况输入，参见下面的注释）

Marvell>> setenv serverip [pchost ip]
Marvell>> setenv ipaddr [device ip]
Marvell>> saveenv
Marvell>> sflash protect off
Marvell>> tftp 0x50000 kernel.img
Marvell>> sflash erase 10-45
Marvell>> sflash write 0x50000 0x000a0000 0x240000
Marvell>> tftp 0x50000 ramfs.img
Marvell>> sflash erase 46-63
Marvell>> sflash write 0x50000 0x002e0000 0x120000
Marvell>> sflash protect on
Marvell>> setenv constargs console=ttyS0,115200n8 mem=512M ip=[device ip]:[pchostip]:[gateway]:[netmask]:[machine name]:eth0:off
Marvell>> setenv mtdparts mtdparts=cafe_nand:1G(rootfs),-(data)
Marvell>> setenv bootramfs setenv bootargs \$(constargs) \$(mtdparts)\;cp.b 0xf80a0000 0x20000 240000\;cp.b 0xf82e0000 0x1000000 0x120000\;bootm 0x20000 0x1000000
Marvell>> saveenv
Marvell>> run bootramfs

注释：如果欲将开发板ip设置为10.1.14.188，PChost的ip为10.1.14.39，则
内核参数"ip="应写作：
ip=10.1.14.188:10.1.14.39:10.1.14.1:255.255.255.0:neusoft:eth0:off
"setenv serverip [pchost ip]" 应写作：
setenv serverip 10.1.14.39
注意中括号不要写上！ machine name可以随便写，例如"neusoft"、"develop"等任何字符串，也可为空。

5.  若以上动作成功，则将引导内核启动，并以刚刚烧入的ramfs.img镜像作为根文件系统。

6.  此后在u-boot下运行run bootramfs即可引导内核启动并以ramfs作为根文件系统。

ramfs启动成功后，minicom将显示类似以下信息：

Run initrd...
SPI Serial flash detected @ 0xf4000000, 4096KB (64sec x 64KB)
Creating 2 MTD partitions on "spi_flash":
0x0000000a0000-0x0000002e0000 : "kernel"
0x0000002e0000-0x000000400000 : "ramfs"
dev:    size       erasesize  name
mtd0: 40000000 00040000 "rootfs"
mtd1: 40000000 00040000 "data"
mtd2: 00240000 00010000 "kernel"
mtd3: 00120000 00010000 "ramfs"
mtd4: 00400000 00010000 "spi_flash"
Server :> /bin/userver started!
Server :> kernel device = /dev/mtd2
Server :> ramfs  device = /dev/mtd3
Server :> rootfs device = /dev/mtd0

请注意对照"kernel"分区的设备号是否是mtd2！如果不是，除非你清楚原因，否则请立即反馈！


小技巧：
minicom自动换行命令为"Ctrl-A W"

注意：
不要随意修改传给内核的参数"mtdparts="。如果该参数并不是将nand flash分成两个区，而是一个或者三个，则启动后分区索引就改变了，比如kernel分区变成/dev/mtd3，此时如果进行Update动作，可能会导致烧写失败。如果错误数据覆盖了内核，则内核无法启动，需要从u-boot重新烧写kernel。


===========================================================================
二、详细操作说明
---------------------------------------------------------------------------
这一部分详细说明了每个步骤的原因以及需要注意之处。有兴趣的同事可以参考。

向 Marvell kw 开发板烧写ramfs，有两种方法，以下分别介绍。
方法一：使用tftp（推荐）
1，在PC端配置tftp服务器，将ramfs.img拷贝到tftp共享目录下。
   tftp的配置说明详见《tftp.txt》文档。

2，从minicom或者hyper terminal进入u-boot

3，设置u-boot环境变量
Marvell>> ipaddr=[开发板的ip]
Marvell>> serverip=[PC host的ip]

4，用tftp命令将ramfs.img下载到内存。
Marvell>> tftp 0x40000 ramfs.img

5，用sflash命令族，将内存中的ramfs.img镜像烧写到nor flash上。
Marvell>> sflash protect off
Marvell>> sflash erase 46-63
Marvell>> sflash write 0x40000 0x2e0000 0x120000
注：sflash erase 46-63 命令的参数，是擦写区块（Sector）的索引。
Marvell kw 开发板上的nor flash的Sector大小为64KiB，从1至63，共64块。
偏移量0x2e0000，正好是从第46个Sector开始，至最后一块，即46-63。

6，重新启动，进入ramfs的过程将在下面介绍。


方法二：使用nfs
如果你已经为Marvell kw建立了一个nfs文件系统，则推荐使用该方法。
该方法的前提是，板载内核已经支持sysfs文件系统。如果使用该方法，在第4步无法导入spi-flash的驱动，则可能需要先更新内核。更新内核则只能通过tftp的方式。
1，建立一个nfs文件系统作为rootfs
2，以该nfs作为rootfs，启动开发板
3，将suu.tar.gz解压至nfs某路径下，得到suu/文件夹
4，进入suu/suu_device/spi_flash_driver_mvl_kw/路径下，运行"./driver.sh"，该脚本导入spi-flash的驱动，并将nor flash分区，可用cat命令查看分区结果：

# cat /proc/mtd
dev:    size       erasesize  name
mtd0: 40000000 00040000 "rootfs"
mtd1: 40000000 00040000 "data"
mtd2: 00240000 00010000 "kernel"
mtd3: 00120000 00010000 "ramfs"
mtd4: 00400000 00010000 "spi_flash"

   前几个mtd设备是nand flash上的分区（共2GiB容量），因为nand flash的驱动在内核初始化时即被自动加载。从名为"U-Boot"的分区开始，是nor flash上的分区，总容量共4M，不过可以看到最后一个分区"spi_flash"本身就4M，因为它不是真正的分区，而是分区总和，我们也不应使用它。

5，进入suu_device路径下，运行./userver -h 可以看到userver需要的参数。ip和port默认即可，但需确保开发板与你的PC host可以建立连接。

6，运行./userver，以Step 4的结果为例，kernel，ramfs和rootfs所在的分区分别应是 /dev/mtd2，/dev/mtd3 和 /dev/mtd0，因此运行userver的命令行为：
   # ./userver -k /dev/mtd2 -r /dev/mtd3 -f /dev/mtd0
   此时userver阻塞并开始监听来自任何ip地址的连接请求。

7，在PC端解压suu.tar.gz包，得到suu/文件夹，进入suu/suu_host/路径。

8，运行路径下的uclient程序。可运行./uclient -h 查看参数代表的意义。
   此时我们希望将ramfs.img烧写到板子上：假设开发板的ip是10.1.14.199，使用默认port。
   # ./uclient -i 10.1.14.199 -r ramfs.img
   此命令若成功，则当前目录下的ramfs.img已烧写到userver -r指定的设备，即/dev/mtd3中。

9，启动进入ramfs的过程将在下面介绍。


===========================================================================
三、如何进入ramfs：
---------------------------------------------------------------------------
使用u-boot引导kernel，以ramfs作为rootfs：
    该开发板不支持对nand操作，只提供对nor flash的操作。这也是为什么我们必须把ramfs烧写到nor flash上的原因。该开发板上有一块nor flash，地址从0xf8000000开始，共4M大小。
    经简单计算可得：
    kernel分区的起始地址为0xf80a0000；
    ramfs分区的起始地址为0xf82e0000；
    因此，以ramfs为根文件系统启动内核的命令为：
Marvell>> setenv bootargs console=ttyS0,115200n8 mem=512M ip=[开发板ip]:[serverip]:[gateway]:255.255.255.0:[开发板名称，随便写，如neusoft]:eth0 mtdparts=cafe_nand:1G(rootfs),-(data)
Marvell>> cp.b 0xf80a0000 0x20000 240000
Marvell>> cp.b 0xf82e0000 0x1000000 0x120000
Marvell>> bootm 0x20000 0x1000000
    以上四条指令分别是：设置内核启动参数；将内核拷贝到内存；将ramfs镜像拷贝到内存；引导内核并将ramfs镜像地址专递给内核。
    注意，若以ramfs作为rootfs启动，则不要设置"root="这个内核参数！
    按照以上步骤操作u-boot，即可启动开发板到ramfs状态。

    若要以nand flash上的正常rootfs启动，则u-boot命令为：
Marvell>> setenv bootargs console=ttyS0,115200n8 mem=512M ip=[开发板ip]:[serverip]:[gateway]:255.255.255.0:[开发板名称，随便写，如neusoft]:eth0 mtdparts=cafe_nand:1G(rootfs),-(data) ubi.mtd=0 root=ubi0:rootfs rootfstype=ubifs rw
Marvell>> cp.b 0xf80a0000 0x20000 240000
Marvell>> bootm 0x20000

    提示：内核参数太长，可以保存为若干个环境变量，如：
Marvell>> setenv constargs console=ttyS0,115200n8 mem=512M ip=[开发板ip]:[serverip]:[gateway]:255.255.255.0:[开发板名称，随便写，如neusoft]:eth0
Marvell>> setenv mtdpartitions mtdparts=cafe_nand:1G(rootfs),-(data)
Marvell>> setenv rootpath ubi.mtd=0 root=ubi0:rootfs rootfstype=ubifs rw
Marvell>> saveenv
    则，正常启动时执行以下命令即可：
Marvell>> setenv $(constargs) $(mtdpartitions) $(rootpath); cp.b 0xf80a0000 0x20000 240000; bootm 0x20000
    甚至也可以将这条命令保存为一个环境变量，注意几处需要使用转义字符"\"：
Marvell>> setenv bootnormal setenv \$(constargs) \$(mtdpartitions) \$(rootpath)\; cp.b 0xf80a0000 0x20000 240000\; bootm 0x20000
Marvell>> saveenv
    此后，只需运行以下指令，即可正常启动开发板，进入rootfs：
Marvell>> run bootnormal


===========================================================================
四、如何使用suu：
---------------------------------------------------------------------------
按照上述操作步骤将内核以ramfs作为根文件系统启动后，spi-flash的驱动已经自动加载，userver也已经启动，默认分区为：
dev:    size   erasesize  name
mtd0: 40000000 00040000 "rootfs"
mtd1: 40000000 00040000 "data"
mtd2: 00240000 00010000 "kernel"
mtd3: 00120000 00010000 "ramfs"
mtd4: 00400000 00010000 "spi_flash"
userver启动后默认将内核设备指定为/dev/mtd2，将ramfs设备指定为/dev/mtd3，将rootfs指定为/dev/mtd0.
以ramfs状态启动后，不需要对设备作任何操作。

在PC端解压suu.tar.gz包，得到suu/文件夹，进入suu/suu_host/路径。
运行路径下的uclient程序。可运行./uclient -h 查看参数代表的意义。
此时如果我们希望将当前路径下的kernel.img，ramfs.img和rootfs.img烧写到板子上：假设开发板的ip是10.1.14.199，使用默认port。则：
# ./uclient -i 10.1.14.199 -k kernel.img -r ramfs.img -f rootfs.img
此命令若成功，则新内核、ramfs和rootfs已烧写到userver指定的设备上。


注意：
不要随意修改传给内核的参数"mtdparts="。如果该参数并不是将nand flash分成两个区，而是一个或者三个，则启动后分区索引就改变了，比如kernel分区变成/dev/mtd3，此时如果进行Update动作，可能会导致烧写失败。如果错误数据覆盖了内核，则内核无法启动，需要从u-boot重新烧写kernel，如果u-boot被覆盖，则开发板将废掉。
在未来的spi-flash驱动版本中，u-boot的分区将被屏蔽掉。


===========================================================================
附件 1  常用的u-boot环境变量的设置 
        参考以下步骤设置u-boot，可以简化日后的操作
---------------------------------------------------------------------------
【假设开发板的ip为 10.1.14.35；PC主机的ip为 10.1.14.37；PC主机上nfs服务器共享路径为/nfsroot/rootfs/】
Marvell>> setenv ipaddr 10.1.14.35
Marvell>> setenv serverip 10.1.14.37
Marvell>> setenv gateway 10.1.14.1
Marvell>> setenv constargs console=ttyS0,115200n8 mem=512M ip=$(ipaddr):$(serverip):$(gateway):255.255.255.0:neusoft:eth0
Marvell>> setenv mtdparts mtdparts=cafe_nand:1G(rootfs),-(data)
Marvell>> setenv rootpath ubi.mtd=0 root=ubi0:rootfs rootfstype=ubifs rw
Marvell>> setenv bootdirect setenv bootargs \$(constargs) \$(mtdparts) \$(rootpath)\;cp.b 0xf80a0000 0x20000 240000\;bootm 0x20000
Marvell>> setenv bootramfs setenv bootargs \$(constargs) \$(mtdparts)\;cp.b 0xf80a0000 0x20000 240000\;cp.b 0xf82e0000 0x1000000 0x120000\;bootm 0x20000 0x1000000
Marvell>> setenv nfsroot root=/dev/nfs nfsroot=$(serverip):/nfsroot/rootfs/,proto=tcp
Marvell>> setenv bootnfs setenv bootargs \$(constargs) \$(mtdparts) \$(nfsroot)\;cp.b 0xf80a0000 0x20000 240000\;bootm 0x20000
Marvell>> setenv bootargs \$(constargs) \$(mtdparts)
Marvell>> setenv bootcmd run \$(bootdirect)
Marvell>> saveenv

按照上述步骤设置完毕之后，每次启动进入u-boot，只需要运行以下几条命令即可：
Marvell>> run bootramfs       引导内核以ramfs作为rootfs启动。
Marvell>> run bootnfs         引导内核以nfs作为rootfs启动。
Marvell>> run bootdirect      引导内核以nand flash上的rootfs镜像作为rootfs启动。
Marvell>> boot                这条命令实际是执行 run bootcmd 命令的快捷方式，因此也等同于执行 run bootdirect 命令。