#ifndef 	_SOCKET_UTIL_H_
#define 	_SOCKET_UTIL_H_


/* ============================ Preprocessor macro definitions start ==*/
#define SRPC_ERROR_OK							(0)
#define SRPC_ERROR_ADDRESS						(-1)
#define SRPC_ERROR_SOCKET						(-2)
#define SRPC_ERROR_CONNECT						(-3)
#define SRPC_ERROR_CONNECT_EXPECT_EINPROGRESS	(-4)
#define SRPC_ERROR_CONNECT_TIMEOUT				(-5)
#define SRPC_ERROR_CONNECT_HAS_ERROR			(-6)
#define SRPC_ERROR_SOCKET_FD_ERROR 				(-7)
/* ============================ Preprocessor macro definitions end ====*/


/* ============================ typedef start =========================*/
#ifndef 	_TYPE_BYTE_
#define 	_TYPE_BYTE_
typedef unsigned char			byte;
#endif // _TYPE_BYTE_
/* ============================ typedef end ===========================*/


/* ============================ function declarations start ===========*/
// public:
void printerr(const char* prompt);

void printerrmsg(const char * prompt,const char * msg);

int send_easy(int socket, const void * buffer, int length, int flags);

int recv_easy(int socket, void * buffer, int length, int flags);

int srpc_init( char* hostname, int port, int timeout, char** svrver );

void srpc_exit(int sock_svr);

int srpc_input(int sock, int srpc_id, int inpu_size, byte* input_buf);

int srpc_output(int sock, int* result, int* output_size, byte** output_buf);

int srpc_call(	int 	sock_svr, 
				int 	srpc_id, 
				byte* 	input, 
				int 	insize, 
				byte** 	output, 
				int* 	outsize,
				int* 	result );

// private:
int connect_server( char* hostname, int port, int timeout );

int greeting(int sock_svr, char** verstr);

/* ============================ function declarations end =============*/


#endif // _SOCKET_UTIL_H_

