﻿ubifs是一种先进的为mtd(memory technology device)设计的文件系统。

ubifs文件系统镜像的制作：
1，准备一个文件系统，不妨令其路径为/usr/local/rootfs
2，在PC上解压suu_host.tar.gz
3，进入suu_host/utils/utils-ubifs/路径下
4，将mkfs.ubifs和ubinize两个应用程序拷贝至任何$PATH包含的路径下，例如/usr/bin/下（推荐）
   如果不允许污染当前PC端环境，则修改mkubifs.sh中的对应的变量，参见mkubifs.sh脚本
5，运行命令：
# ./mkubifs.sh <output imagename> <rootfs dir> [volume size] [volume name]
例如 ./mkubifs.sh rootfs_new.img /usr/local/rootfs 800MiB rootfs
说明：
output imagename : 输出的ubifs镜像文件名。
rootfs dir : 将被制成ubifs镜像的文件系统的路径。
volume size : 文件系统容量，ubifs镜像支持的最大容量，flash分区上至少有这些空间才可烧写该镜像。
volume name : 文件系统名字，该名字很重要，将作为内核参数的一部分被传入内核。
请参考文档《suu_kw_readme.txt》，内核参数中"ubi.mtd=0 root=ubi0:rootfs rootfstype=ubifs rw"这一部分，其中root=ubi0:rootfs的"rootfs"即为此处的volume name。
在mkubifs.sh脚本中，volume name 默认为"rootfs"。

在mkubifs.sh脚本中，方便起见，默认了一些平台相关的参数，比如最小io尺寸，物理擦除块和逻辑擦除块的大小等。
目前脚本中的默认值适合 Marvell_kw 开发板上的三星nand flash存储器。
如果要使用mkubifs.sh为其他flash（如nor flash或不同的nand flash）生成ubifs镜像，就需要修改mkubifs.sh脚本中的相关变量。
这些变量集中应用在为ubinize程序生成临时配置文件的命令段中。详细信息请看如下例子：

例一：32MiB NOR flash with 128KiB physical eraseblock size.

制作镜像的命令应为：

# mkfs.ubifs -r root-fs -m 1 -e 130944 -c 255 -o ubifs.img
# ubinize -o ubi.img -m 1 -p 128KiB ubinize.cfg

它的 ubinize.cfg 文件应包括:

# cat ubinize.cfg
[ubifs]
mode=ubi
image=ubifs.img
vol_id=0
vol_size=30MiB
vol_type=dynamic
vol_name=rootfs
vol_alignment=1
vol_flags=autoresize


例二：512MiB MLC NAND flash with 128KiB physical eraseblock size, 2048 bytes NAND page size and no sub-page write support.

# mkfs.ubifs -r root-fs -m 2048 -e 126976 -c 4095 -o ubifs.img
# ubinize -o ubi.img -m 2048 -p 128KiB ubinize.cfg

它的 ubinize.cfg 文件应包括:

# cat ubinize.cfg
[ubifs]
mode=ubi
image=ubifs.img
vol_id=0
vol_size=450MiB
vol_type=dynamic
vol_name=rootfs
vol_alignment=1
vol_flags=autoresize


如需要获得更多信息，请参考：
1，mkubifs.sh 文件中的注释
2，《ubifs_guide.txt》文档