
char* sysinfo_getmtd(char** mtdinfo, int * cnt);
char* sysinfo_getversion(char* vers, int size);
long int sysinfo_getmeminfo(long int* totalm, long int* freem);
char* sysinfo_gethostname(char* hname, int size);

