/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */

/* Hildon includes */
#include <hildon/hildon-note.h>
#include <hildon/hildon-banner.h>
#include <hildon/hildon-sound.h>
#include <hildon/hildon-defines.h>
#include <libhildondesktop/libhildondesktop.h>

#include <log-functions.h>
#include <libosso.h>
#include <osso-log.h>

/* GTK includes */
#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdkpixbuf.h>

/* Systems includes */
#include <string.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
/*lkadd{*/
/*#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <sys/msg.h>*/
#include <glib.h>
/*for receive*/
# define OSSO_EXAMPLE_NAME       "hello_statusbar"
# define OSSO_EXAMPLE_SERVICE    "com.nokia."OSSO_EXAMPLE_NAME
# define OSSO_EXAMPLE_OBJECT     "/com/nokia/"OSSO_EXAMPLE_NAME
# define OSSO_EXAMPLE_IFACE      "com.nokia."OSSO_EXAMPLE_NAME

/*for send*/
# define OSSO_EXAMPLE2_NAME       "hello_homearea"
# define OSSO_EXAMPLE2_SERVICE    "com.nokia."OSSO_EXAMPLE2_NAME
# define OSSO_EXAMPLE2_OBJECT     "/com/nokia/"OSSO_EXAMPLE2_NAME
# define OSSO_EXAMPLE2_IFACE      "com.nokia."OSSO_EXAMPLE2_NAME
#define OSSO_EXAMPLE2_MESSAGE "hidearea"

/*lkadd}*/

#include "hello-world-statusbar.h"
#include "libhelloworld.h"

HD_DEFINE_PLUGIN(HildonStatusBarHelloWorld,
		 hildon_status_bar_helloworld,
	       	 STATUSBAR_TYPE_ITEM);

#define HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(x) \
	    (G_TYPE_INSTANCE_GET_PRIVATE((x), \
                                         hildon_status_bar_helloworld_get_type(), \
                                         HildonStatusBarHelloWorldPrivate));

static void hildon_status_bar_helloworld_finalize(GObject *object);

static void hildon_status_bar_helloworld_class_init(
		HildonStatusBarHelloWorldClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS(klass);
    object_class->finalize = hildon_status_bar_helloworld_finalize;
    g_type_class_add_private(klass, sizeof(HildonStatusBarHelloWorldPrivate));
}

static void set_helloworld_icon(const gchar *name, HildonStatusBarHelloWorldPrivate *info)
{
    GtkIconTheme *icon_theme;
    GdkPixbuf    *pixbuf;

    icon_theme = gtk_icon_theme_get_default();

    pixbuf = (name != NULL) ? gtk_icon_theme_load_icon(icon_theme, name,
                                                       HILDON_STATUS_BAR_HELLOWORLD_ICON_SIZE,
                                                       GTK_ICON_LOOKUP_NO_SVG, NULL) : NULL;

    gtk_image_set_from_pixbuf(GTK_IMAGE(info->icon), pixbuf);

    if (pixbuf != NULL)
        g_object_unref(pixbuf);
}

static void hildon_status_bar_helloworld_finalize(GObject *object)
{
    HildonStatusBarHelloWorldPrivate *info = HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(object);

    osso_deinitialize(info->osso);

    LOG_CLOSE();

    G_OBJECT_CLASS(g_type_class_peek_parent(G_OBJECT_GET_CLASS(object)))->finalize(object);
}
/*lkadd*/
void my_button_pressed(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
	/*GtkWidget *button;
	g_print("my button_pressed");
	gtk_widget_hide(widget); */
    osso_context_t *osso_context;
   // osso_rpc_t retval;
    osso_return_t ret;
    /* Initialize maemo application */
    osso_context = osso_initialize(OSSO_EXAMPLE2_SERVICE, "0.0.1", TRUE, NULL);
	static gint flag = 0;
    /* Check that initialization was ok */
    if (osso_context == NULL) {
        //return OSSO_ERROR;
		g_print ("Error initialize osso in homearea\n");
		return;
    }
    ret = osso_rpc_run(osso_context, 
				       OSSO_EXAMPLE2_SERVICE, 
				       OSSO_EXAMPLE2_OBJECT, 
				       OSSO_EXAMPLE2_IFACE, 
				       (flag^=1)==1?OSSO_EXAMPLE2_MESSAGE:"showarea", NULL/*&retval*/, DBUS_TYPE_INVALID);/*关键发送消息*/
    //osso_rpc_free_val(&retval);
    osso_deinitialize(osso_context);
	g_print("home button1 test\n");
/*    g_signal_emit_by_name (G_OBJECT (((struct _HildonStatusBarHelloWorld)data)->parent),
                         "hildon_status_bar_update_conditional",
                         FALSE,
                         NULL);*/
}

/*for dbus*/
gint dbus_req_handler (const gchar * interface , const gchar * method ,
                       GArray * arguments , gpointer data ,
                       osso_rpc_t * retval )
{
    char *appdata ;
    appdata = (char*) data;
	g_print(method);
    g_print("good!Message transfered from homearea to statusbar");
	//osso_rpc_free_val ( retval );
	//if(!g_strcmp0((char*)method, "hide"))
	if(method[0] == 'h')
		gtk_widget_hide(GTK_WIDGET(data));
	else
		gtk_widget_show(GTK_WIDGET(data));
    return OSSO_OK ;

}
/*lkadd*/
static void hildon_status_bar_helloworld_init(HildonStatusBarHelloWorld *helloworld)
{
    HildonStatusBarHelloWorldPrivate *info = 
        HILDON_STATUS_BAR_HELLOWORLD_GET_PRIVATE(helloworld);

	/*lkadd{
	GtkWidget *entry;
	entry = gtk_entry_new();
	*/

	osso_return_t result ;/*for dbus*/
    /*GtkWidget *tmpImage;
    tmpImage = gtk_image_new_from_file("/usr/share/icons/hicolor/scalable/hildon/hello-world.png");*/
    /*lkadd}*/
    ULOG_OPEN("hildon-sb-helloworld");

    g_return_if_fail(info);

    info->icon = gtk_image_new_from_pixbuf(NULL);
    info->button = gtk_toggle_button_new();/*lkcomment button on the status bar*/

    set_helloworld_icon("hello-world", info);

    gtk_container_add(GTK_CONTAINER(info->button),
                      GTK_WIDGET(info->icon));/*lkdel*/


	/*lkadd{*/
//	gtk_container_add(GTK_CONTAINER(info->button),
//			tmpImage);
	//gtk_widget_show(entry);
	//gtk_entry_set_text(GTK_ENTRY(entry), "hello");/*lkadd}*/

	gtk_container_add(GTK_CONTAINER(helloworld), info->button);

    /* Signal for icon (button) */
    /*g_signal_connect(G_OBJECT(info->button), "button-press-event",
                     G_CALLBACK(hello_world_dialog_show), NULL);*/
    g_signal_connect(G_OBJECT(info->button), "button-press-event",
                     G_CALLBACK(my_button_pressed), helloworld);/*lkupdate,add signal to the statusbar button*/

    /* Initialize osso */
    info->osso = osso_initialize("hildon_sb_helloworld", "1.0", FALSE, NULL);
    if (!info->osso)
        ULOG_WARN("%s: error while initializing osso\n", __FUNCTION__);


	/*lkadd{*/
    /*关键为D-BUS的会话bus添加回调函数 */
    result = osso_rpc_set_cb_f(info->osso,
			                    OSSO_EXAMPLE_SERVICE ,
			                    OSSO_EXAMPLE_OBJECT ,
			                    OSSO_EXAMPLE_IFACE ,
			                    dbus_req_handler , info->button);
	    if ( result != OSSO_OK )
		{
		      g_print ("Error setting D-BUS callback (%d) in statusbar\n", result );
		      /*return OSSO_ERROR ;*/
		      return ;
		}
	/*lkadd}*/

    gtk_widget_show_all(GTK_WIDGET(helloworld));
}
