/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */


#ifndef LIBHELLOWORLD_H
#define LIBHELLOWORLD_H

#include <gtk/gtk.h>

GtkWindow *hello_world_new (void);
GtkDialog *hello_world_dialog_new (void);
GtkWidget *hello_world_button_new (int padding);

void hello_world_dialog_show (void);


#endif /* !LIBHELLOWORLD_H */
