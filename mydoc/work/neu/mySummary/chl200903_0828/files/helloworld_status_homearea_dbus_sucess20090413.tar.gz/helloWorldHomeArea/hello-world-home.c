/*
 * This file is part of hello-world-app
 *
 * Copyright (C) 2006-2008 Nokia Corporation. All rights reserved.
 *
 * This maemo code example is licensed under a MIT-style license,
 * that can be found in the file called "COPYING" in the package
 * root directory.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>

#include <glib.h>
#include <gtk/gtk.h>

#include <libhildondesktop/libhildondesktop.h>

#include "hello-world-home.h"
#include "libhelloworld.h"


/*lkadd{*/
/*#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <sys/msg.h>*/
#include <libosso.h>
/*for send*/
# define OSSO_EXAMPLE_NAME       "hello_statusbar"
# define OSSO_EXAMPLE_SERVICE    "com.nokia."OSSO_EXAMPLE_NAME
# define OSSO_EXAMPLE_OBJECT     "/com/nokia/"OSSO_EXAMPLE_NAME
# define OSSO_EXAMPLE_IFACE      "com.nokia."OSSO_EXAMPLE_NAME
#define OSSO_EXAMPLE_MESSAGE "hide"

/*for receive*/
# define OSSO_EXAMPLE2_NAME       "hello_homearea"
# define OSSO_EXAMPLE2_SERVICE    "com.nokia."OSSO_EXAMPLE2_NAME
# define OSSO_EXAMPLE2_OBJECT     "/com/nokia/"OSSO_EXAMPLE2_NAME
# define OSSO_EXAMPLE2_IFACE      "com.nokia."OSSO_EXAMPLE2_NAME
/*lkadd}*/

HD_DEFINE_PLUGIN (HelloHomePlugin, hello_home_plugin, HILDON_DESKTOP_TYPE_HOME_ITEM);
/*lkadd{*/
gint dbus_req_handler (const gchar * interface , const gchar * method ,
                       GArray * arguments , gpointer data ,
                       osso_rpc_t * retval )
{
    char *appdata ;
    appdata = (char*) data;
	g_print(method);
    g_print("good!Message transfered from statusbar to homearea ");
	//osso_rpc_free_val ( retval );
	//if(!g_strcmp0((char*)method, "hidearea"))
	if(method[0] == 'h')
		gtk_widget_hide(GTK_WIDGET(data));
	else
		gtk_widget_show(GTK_WIDGET(data));
    return OSSO_OK ;

}
static void my_button(GtkWidget *button, gpointer data)
{
    osso_context_t *osso_context;
   // osso_rpc_t retval;
    osso_return_t ret;
    /* Initialize maemo application */
    osso_context = osso_initialize(OSSO_EXAMPLE_SERVICE, "0.0.1", TRUE, NULL);
	static gint flag = 0;
    /* Check that initialization was ok */
    if (osso_context == NULL) {
        //return OSSO_ERROR;
		g_print ("Error initialize osso in homearea\n");
		return;
    }
    ret = osso_rpc_run(osso_context, 
				       OSSO_EXAMPLE_SERVICE, 
				       OSSO_EXAMPLE_OBJECT, 
				       OSSO_EXAMPLE_IFACE, 
				       (flag^=1)==1?OSSO_EXAMPLE_MESSAGE:"show", NULL/*&retval*/, DBUS_TYPE_INVALID);/*关键发送消息*/
    //osso_rpc_free_val(&retval);
    osso_deinitialize(osso_context);
	g_print("home button1 test\n");
}
/*lkadd}*/
static void
hello_home_plugin_init (HelloHomePlugin *home_plugin)
{
  GtkWidget *button;
  GtkWidget *button1;
  GtkWidget *hbox;
  osso_context_t *osso_context;
  osso_return_t result ;/*for dbus*/

  
  hbox = gtk_hbox_new(TRUE, 0);
  gtk_container_add (GTK_CONTAINER (home_plugin), hbox);

  button = hello_world_button_new (10);
  g_signal_connect (button, "clicked",
		    G_CALLBACK (hello_world_dialog_show),
		    NULL);

  gtk_box_pack_start(GTK_BOX(hbox),button, TRUE, TRUE, 0);
  
  //gtk_widget_show_all (button);

  button1 = gtk_button_new_with_label("show_hide");
  g_signal_connect(G_OBJECT(button1), "clicked", G_CALLBACK(my_button), NULL);
  gtk_box_pack_start(GTK_BOX(hbox),button1, TRUE, TRUE, 0);
  /* Set the resizing behavior */
  hildon_desktop_home_item_set_resize_type (HILDON_DESKTOP_HOME_ITEM (home_plugin),
                                            HILDON_DESKTOP_HOME_ITEM_RESIZE_BOTH);

  /*lkadd for receive*/

    osso_context = osso_initialize("hello_homearea", "1.0", FALSE, NULL);
    if (osso_context)
        /*ULOG_WARN("%s: error while initializing osso_context\n", __FUNCTION__);*/
        g_print("error while initializing osso_context\n");


	/*lkadd{*/
    /*关键为D-BUS的会话bus添加回调函数 */
    result = osso_rpc_set_cb_f(osso_context,
			                    OSSO_EXAMPLE2_SERVICE ,
			                    OSSO_EXAMPLE2_OBJECT ,
			                    OSSO_EXAMPLE2_IFACE ,
			                    dbus_req_handler , button1);
	    if ( result != OSSO_OK )
		{
		      g_print ("Error setting D-BUS callback (%d) in statusbar\n", result );
		      /*return OSSO_ERROR ;*/
		      return ;
		}
    /*osso_deinitialize(osso_context);这里需要在销毁窗口的时候调用*/

	/*lkadd}*/
  /*lkadd for receive*/

  gtk_widget_show_all(hbox);
}

static void
hello_home_plugin_class_init (HelloHomePluginClass *class)
{
}

