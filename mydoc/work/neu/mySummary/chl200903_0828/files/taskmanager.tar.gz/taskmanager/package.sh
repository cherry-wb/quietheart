#!/bin/bash

if [[ "$#" > 2 || "$#" == 0 ]]
then
	echo "Usage: package.sh [x86_x11 | m_arm_x11] DIR"
	exit 1
fi

if [[ "$#" == 2 ]]
then
	shift
fi

DEST=$1
TMPLUGIN=libtaskmanager.so
TMDESKTOP=taskmanager.desktop

if [ ! -e "$TMPLUGIN" -o ! -e "$TMDESKTOP" ]
then
	echo "no target!"
	exit 1
fi

cp -f "$TMPLUGIN" "$DEST"
cp -f "$TMDESKTOP" "$DEST"
cp -f install.sh "$DEST"
cp -f taskmanager.png "$DEST"
