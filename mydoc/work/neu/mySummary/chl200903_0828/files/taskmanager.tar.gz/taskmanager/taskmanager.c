#include <libhildondesktop/hildon-status-bar-item.h>
#include <libhildondesktop/libhildondesktop.h>
#include <libhildonwm/hd-wm.h>


typedef struct
{
	HildonStatusBarItem *item;
	GtkWidget *button;
}TaskManagerPlugin;

static void task_manager_position_func(GtkMenu *menu,
		gint *x, gint *y,
		gboolean *push_in, gpointer user_data)
{/*lkcomment用来定位弹出菜单位置的函数*/
	// *x = 52;
	*x = 400;
	*y = 52;
	*push_in = FALSE;
}


static void active_desktop(void)
{
	hd_wm_top_desktop();
}


static void active_window(gpointer data)
{
	HDWMApplication *app;
	HDWMEntryInfo *app_info;

	app = HD_WM_APPLICATION(data);
	app_info = HD_WM_ENTRY_INFO(hd_wm_application_get_active_window(app));
	hd_wm_top_item(app_info);
}


static GtkWidget *task_manager_create_menu()
{/*lkcomment这里将建立taskmanager中的菜单，每个菜单项代表一个应用程序*/
	GtkWidget *tm_menu;
	GtkWidget *menu_item;
	GtkWidget *image = NULL;
	HDWM *hdwm;
	GList *list = NULL;

	tm_menu = gtk_menu_new();

	hdwm = hd_wm_get_singleton();

	for(list = hd_wm_get_applications(hdwm); list; list = g_list_next(list))
	{
		const gchar *title =
			hd_wm_application_get_name((HDWMApplication *)list->data);
		menu_item = gtk_image_menu_item_new_with_label(title);
		const gchar *icon_name =
			hd_wm_application_get_icon_name((HDWMApplication *)list->data);
		image = gtk_image_new_from_icon_name(icon_name, GTK_ICON_SIZE_MENU);
		gtk_image_menu_item_set_image((GtkImageMenuItem *)menu_item,
				image);
		gtk_menu_shell_append(GTK_MENU_SHELL(tm_menu), menu_item);
		g_signal_connect_swapped(G_OBJECT(menu_item), "activate",
				G_CALLBACK(active_window), (gpointer)list->data);/*lkcomment这里点击taskmanager中的按钮则激活相应的程序*/
		gtk_widget_show(menu_item);

		GtkWidget *sep_item = gtk_separator_menu_item_new();
		gtk_widget_show(sep_item);
		gtk_menu_shell_append(GTK_MENU_SHELL(tm_menu), sep_item);
	}

	menu_item = gtk_image_menu_item_new_with_label("Desktop");
	image = gtk_image_new_from_icon_name("gohome", GTK_ICON_SIZE_MENU);
	gtk_image_menu_item_set_image(GTK_IMAGE_MENU_ITEM(menu_item), image);
	gtk_menu_shell_append(GTK_MENU_SHELL(tm_menu), menu_item);

	g_signal_connect_swapped(G_OBJECT(menu_item), "activate",
			G_CALLBACK(active_desktop), NULL);/*lkcomment这里点击taskmanager中的返回桌面按钮激活相应的程序*/
	gtk_widget_show(menu_item);

	return tm_menu;
}


static void on_clicked(GtkWidget *button, gpointer data)
{/*lkcomment点击状态栏上面的taskmanager按钮相应的映射函数,会弹出菜单*/
	GtkWidget *tm_menu;
	tm_menu = task_manager_create_menu();
	gtk_menu_popup(GTK_MENU(tm_menu),
			NULL, NULL,
			task_manager_position_func, NULL,
			0, gtk_get_current_event_time());
}


static void *task_manager_initialize(HildonStatusBarItem *item, GtkWidget **button)
{
	GtkWidget *image = NULL;
	TaskManagerPlugin *tm_plugin = g_new0(TaskManagerPlugin, 1);
	tm_plugin->item = item;
	*button = tm_plugin->button = gtk_button_new();
	gtk_button_set_relief(GTK_BUTTON(*button), GTK_RELIEF_NONE);/*lkcomment表示按钮边缘的一个属性*/

	// image = gtk_image_new_from_icon_name("gnome-window-manager", GTK_ICON_SIZE_MENU);
	image = gtk_image_new_from_file("/usr/share/mobile-basic-flash/taskmanager.png");
	gtk_widget_show(image);
	gtk_container_add(GTK_CONTAINER(*button), image);
	g_signal_connect(G_OBJECT(*button), "clicked",
			G_CALLBACK(on_clicked), NULL);

	gtk_widget_show_all(*button);
	return (void *)tm_plugin;
}


static void task_manager_update(void *data, gint value1, gint value2, const gchar *str)
{
	if (data != NULL)
	{
		TaskManagerPlugin *tm_plugin = (TaskManagerPlugin *) data;
		if (value1 == 0)
			gtk_widget_destroy(GTK_WIDGET(tm_plugin->item));
		else
			gtk_widget_show_all(tm_plugin->button);
	}
}


static void task_manager_destroy(void *data)
{
    if(data != NULL)
    {
      g_free(data);
    }
}


void taskmanager_entry(HildonStatusBarPluginFn_st *fn) 
{ 
	if(fn != NULL)
	{ 
		fn->initialize = task_manager_initialize; 
		fn->destroy = task_manager_destroy; 
		fn->update = task_manager_update; 
	}
} 

