#!/bin/bash

TMPLUGIN=libtaskmanager.so
TMDESKTOP=taskmanager.desktop

BIN=/usr/lib/hildon-status-bar/
APP=/usr/share/applications/hildon-status-bar/
BARCONF=/etc/hildon-desktop/statusbar.conf

CONFENTRY='[/usr/share/applications/hildon-status-bar/taskmanager.desktop]'
# DISPLAYSWITCH='[/usr/share/applications/hildon-status-bar/hildon-status-bar-displayswitch.desktop]'
DISPLAYSWITCH='[/usr/share/applications/hildon-status-bar/hildon-status-bar-setgroup.desktop]'
PPP='[/usr/share/applications/hildon-status-bar/hildon-status-bar-ppp.desktop]'

if [ ! -e "$TMPLUGIN" -o ! -e "$TMDESKTOP" ]
then
	echo "no target!"
	exit 1
fi

install -D -m 644 "$TMPLUGIN" "$BIN"
install -D -m 644 "$TMDESKTOP" "$APP"

sed -i '/taskmanager/d' "$BARCONF"
sed -i '/displayswitch/d' "$BARCONF"
sed -i '/ppp/d' "$BARCONF"

sed -i "1i\\$CONFENTRY" "$BARCONF"
sed -i "\$a\\$DISPLAYSWITCH" "$BARCONF"
# sed -i "\$a\\$PPP" "$BARCONF"

install -D -m 644 $TMPLUGIN $BIN/$TMPLUGIN
install -D -m 644 $TMDESKTOP $APP/$TMDESKTOP
install -D -m 644 taskmanager.png /usr/share/mobile-basic-flash/
