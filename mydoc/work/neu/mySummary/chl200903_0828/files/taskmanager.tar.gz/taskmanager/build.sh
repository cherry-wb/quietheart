#!/bin/bash

platform=

if [ $# -lt 1 ]
then
	make
	exit 1
fi


for var in $*
do
	case $var in
		x86_x11)
			platform="X86"
			make
			exit 0
			;;
		m_arm_x11)
			platform="ARM"
			make
			exit 0
			;;
		clean)
			clean_flag="1"
			make clean
			exit 0
			;;
		*)
			echo "Usage: build.sh [x86_x11 | m_arm_x11] [clean]"
			exit 1
			;;
	esac
done
